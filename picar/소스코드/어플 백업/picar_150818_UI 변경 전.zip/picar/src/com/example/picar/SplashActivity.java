package com.example.picar;

import java.util.List;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

public class SplashActivity extends Activity {
	
	private static final String WIFI_SSID = "PiCar";
	private static final String WIFI_PASSWORD = "01025645448";
	
	private WifiManager wifiManager;
	private BroadcastReceiver wifiReceiver;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		
		
		// 로딩 이미지, 애니메이션 적용
		ImageView image = (ImageView) findViewById(R.id.image_loading);
		Animation anim = AnimationUtils.loadAnimation(this, R.anim.loading_alpha);
		image.startAnimation(anim);
		
		
		// WiFi 설정
		String message = "";
		wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
		if (!wifiManager.isWifiEnabled()) {
			wifiManager.setWifiEnabled(true);
			message = "Wi-Fi On.\n";
		}
		message += "PiCar Wi-Fi에 연결합니다.";
		Toast.makeText(this, message, Toast.LENGTH_LONG).show();
		
		// PiCar 연결
		wifiManager.startScan();
		wifiReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				if (intent.getAction().equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {
					searchWifi();
				}
			}
		};

		
		// 2초 후 메인 화면으로
		IntentFilter filter = new IntentFilter();
		filter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
		registerReceiver(wifiReceiver, filter);
		
		Handler hd = new Handler();
		hd.postDelayed(new Runnable() {
			public void run() {
				unregisterReceiver(wifiReceiver);
				startActivity(new Intent(getApplicationContext(), MainActivity.class));
				finish();
			}
		}, 2000);
	}
	
	private void searchWifi() {
		List<ScanResult> apList = wifiManager.getScanResults();
		
		if (wifiManager.getScanResults() != null) {
			for (int i=0; i<apList.size(); i++) {
				ScanResult scanResult = apList.get(i);
				
				if (WIFI_SSID.equals(scanResult.SSID)) {
					
					WifiConfiguration wfc = new WifiConfiguration();
					wfc.SSID = "\"".concat(WIFI_SSID).concat("\"");
					wfc.status = WifiConfiguration.Status.DISABLED;
					wfc.priority = 40;
					
					// WPA or WPA2
					wfc.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
					wfc.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
					wfc.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
					wfc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
					wfc.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
					wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
					wfc.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
					wfc.preSharedKey = "\"".concat(WIFI_PASSWORD).concat("\"");
					
					int networkId = wifiManager.addNetwork(wfc);
					Log.d("SplashActivity", "try connect, networkId : " + scanResult.SSID);
					if (networkId != -1) {
						wifiManager.enableNetwork(networkId, true);
					}
				}
			}
		}
	}
}

