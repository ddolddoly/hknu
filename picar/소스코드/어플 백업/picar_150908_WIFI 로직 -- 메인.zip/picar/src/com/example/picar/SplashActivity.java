package com.example.picar;

import android.app.Activity;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

public class SplashActivity extends Activity {
	
	long time = 2000;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		
		
		// 로딩 이미지, 애니메이션 적용
		ImageView image = (ImageView) findViewById(R.id.image_loading);
		Animation anim = AnimationUtils.loadAnimation(this, R.anim.loading_alpha);
		image.startAnimation(anim);
		
		
		// WiFi 사용 설정
		WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
		if (!wifiManager.isWifiEnabled()) {
			wifiManager.setWifiEnabled(true);
			time = 3000;
			String message = "PiCar 연결을 위해 Wi-Fi를 사용합니다.";
			Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
		}
		
		
		// 3초 후 메인 화면으로
		Handler hd = new Handler();
		hd.postDelayed(new Runnable() {
			public void run() {
				startActivity(new Intent(getApplicationContext(), MainActivity.class));
				finish();
			}
		}, time);
	}
}

