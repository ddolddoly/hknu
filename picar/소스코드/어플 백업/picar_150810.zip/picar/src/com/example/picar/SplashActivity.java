package com.example.picar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class SplashActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		
		// 로딩 이미지, 애니메이션 적용
		ImageView image = (ImageView) findViewById(R.id.image_loading);
		Animation anim = AnimationUtils.loadAnimation(this, R.anim.loading_alpha);
		image.startAnimation(anim);
		
		// 2초 후 메인 화면으로
		Handler hd = new Handler();
		hd.postDelayed(new Runnable() {
			public void run() {
				startActivity(new Intent(getApplicationContext(), MainActivity.class));
				finish();
			}
		}, 2000);
	}
}

