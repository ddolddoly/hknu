package com.example.picar;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.nhn.android.maps.NMapLocationManager;
import com.nhn.android.maps.NMapLocationManager.OnLocationChangeListener;
import com.nhn.android.maps.maplib.NGeoPoint;

public class MainActivity extends FragmentActivity {

	// 통신 프로토콜
	private static final byte PROTOCOL_MOTOR = 'M';
	// private static final byte PROTOCOL_GPS = 'G';
	
	
	// 모터 조종 프로토콜
	private static final byte MOTOR_FORWARD = 'F';
	private static final byte MOTOR_BACKWARD = 'B';
	private static final byte MOTOR_TURN_LEFT = 'L';
	private static final byte MOTOR_TURN_RIGHT = 'R';
	private static final byte MOTOR_STOP = 'S';
	private static final byte MOTOR_AUTO = 'A';
	private static final byte MOTOR_SPEED_CHANGE = 'P';
	
	private static final byte MARKER_POINT = 0;
	private static final byte MARKER_MY_LOCATION = 1;
	private static final byte MARKER_CAR = 2;
	
	
	// 통신 변수
	private static String SERVER_IP = "0.0.0.0";
	private static String CLIENT_IP = "0.0.0.0";
	private static final int SERVER_PORT = 2049;
	private static final int CLIENT_PORT = 2048;
	private DatagramSocket serverSocket;
	private DatagramSocket clientSocket;
	private ReceiveTask receiveTask;
	//private Handler handler;
	
	
	// 제어 변수
	private boolean isRunning = false;
	private boolean isAuto = false;
	private boolean isCamera = false;
	private int favoriteCount = 1;
	
	
	// 맵
	private GoogleMap mapView;
	private NMapLocationManager nMapLocationManager;
	private MyLocationListener locationListener;
	private MarkerOptions markerPoint;
	private MarkerOptions markerMyLocation;
	private MarkerOptions markerCar;
	private LocationManager locationManager;
	// 맵 제어
	private boolean markerPointSearchFlag = false;
	private boolean markerMyLocationCenterFlag = false;
	private boolean markerMyLocationSearchFlag = false;
	private boolean markerCarSearchFlag = false;
	
	
	// DB
	private DBManager dbManager;
	
	
	// 뷰
	private WebView webCamera;
	private ImageButton btnCamera;
	private ImageButton btnAdjust;
	private ImageButton btnFavorite;
	private LayoutInflater inflater;
	private LinearLayout layoutMap;
	private LinearLayout layoutFavorite;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		
		
		/***************************
		 ******** 뷰 초기화 ********
		 ***************************/
		webCamera = (WebView) findViewById(R.id.webview_camera);
		btnCamera = (ImageButton) findViewById(R.id.button_camera);
		btnAdjust = (ImageButton) findViewById(R.id.button_adjust);
		btnFavorite = (ImageButton) findViewById(R.id.button_favorite);
		layoutMap = (LinearLayout) findViewById(R.id.layout_map);
		layoutFavorite = (LinearLayout) findViewById(R.id.layout_favorite);
		
		ImageButton btnForward = (ImageButton) findViewById(R.id.button_forward);
		ImageButton btnLeft = (ImageButton) findViewById(R.id.button_left);
		ImageButton btnRight = (ImageButton) findViewById(R.id.button_right);
		ImageButton btnBackward = (ImageButton) findViewById(R.id.button_backward);
		ImageButton btnAuto = (ImageButton) findViewById(R.id.button_auto);
		SeekBar seekBar = (SeekBar) findViewById(R.id.seek_speed);

		mapView = ((SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.map)).getMap();
		
		
		
		/**********************************
		 ******** 뷰 이벤트 바인딩 ********
		 **********************************/
		btnCamera.setOnClickListener(new CameraButtonEvent());
		btnAdjust.setOnClickListener(new AdjustButtonEvent());
		btnFavorite.setOnClickListener(new FavoriteLayoutEvent());
		btnForward.setOnTouchListener(new MotorControlButtonEvent());
		btnLeft.setOnTouchListener(new MotorControlButtonEvent());
		btnRight.setOnTouchListener(new MotorControlButtonEvent());
		btnBackward.setOnTouchListener(new MotorControlButtonEvent());
		btnAuto.setOnTouchListener(new MotorControlButtonEvent());
		seekBar.setOnSeekBarChangeListener(new MotorSpeedControlEvent());

		mapView.setOnMapLongClickListener(new GoogleMapMarkerEvent());
		mapView.setInfoWindowAdapter(new MarkerInfoWindowAdapter());
		mapView.setOnInfoWindowClickListener(new InfoWindowClickEvent());
		mapView.setOnMarkerClickListener(new OnMarkerClickListener() {
			@Override
			public boolean onMarkerClick(Marker marker) {
				return true; // true : 구글 마커의 default control off
			}
		});
		
		
		
		/****************************
		 ******* 기타 초기화 ********
		 ****************************/
		init();
	}
	
	
	// 초기화
	@SuppressLint({ "DefaultLocale", "HandlerLeak" })
	private void init() {
		
		/*************************
		 ******* 통신 설정 *******
		 *************************/
		// IP 얻어오기
		WifiManager wm = (WifiManager) getSystemService(WIFI_SERVICE);
		DhcpInfo dhcpInfo = wm.getDhcpInfo();
		
		// 접속한 AP의 IP
		int client = dhcpInfo.gateway;
		CLIENT_IP = String.format("%d.%d.%d.%d", client & 0xff, client >> 8 & 0xff, client >> 16 & 0xff, client >> 24 & 0xff);
		Log.d("IP Address", "CLIENT IP : " + CLIENT_IP);
		
		// 단말기의 WIFI IP
		int server = dhcpInfo.ipAddress;
		SERVER_IP = String.format("%d.%d.%d.%d", server & 0xff, server >> 8 & 0xff, server >> 16 & 0xff, server >> 24 & 0xff);
		Log.d("IP Address", "SERVER IP : " + SERVER_IP);
		
		// UDP 소켓 생성
		try {
			InetAddress address = InetAddress.getByName(SERVER_IP);
			serverSocket = new DatagramSocket(SERVER_PORT, address);
			clientSocket = new DatagramSocket();
		} catch (Exception e) {
			Log.d("UDP Socket", "Create Error", e);
		}
		
		// UDP 패킷 수신 태스크
		isRunning = true;
		receiveTask = new ReceiveTask();
		receiveTask.execute(null, null, null);
		
		// UDP 패킷 테스트 송신
		byte[] message = new byte[] {PROTOCOL_MOTOR, MOTOR_STOP};
		new Thread(new SendThread(message)).start();
		
		
		/**************************
		 ******** 맵 설정 *********
		 **************************/
		// 맵 시작위치 설정
		LatLng startPoint = new LatLng(37.01129, 127.26420); // 학교
		mapView.moveCamera(CameraUpdateFactory.newLatLngZoom(startPoint, 17));
		
		// 마커 설정
		markerPoint = new MarkerOptions();
		markerMyLocation = new MarkerOptions();
		markerCar = new MarkerOptions();
		markerPoint.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_point));
		markerMyLocation.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_my_location));
		markerCar.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_my_location));
		markerMyLocationCenterFlag = true; // 최초 호출 시 내 위치로 이동
		
		// GPS 설정... 내 위치 검색은 네이버맵 API 이용
		nMapLocationManager = new NMapLocationManager(getApplicationContext());
		locationListener = new MyLocationListener();
        locationManager = (LocationManager) this.getSystemService(LOCATION_SERVICE);
        checkGPSEnable();
        
        
        
        /*************************
         ******* 기타 설정 *******
         *************************/
		inflater = getLayoutInflater();
		
		// db 설정
		dbManager = new DBManager(this, "point.db", null, 1);
		
		// 저장된 즐겨찾기 포인트 불러오기
		ArrayList<ArrayList<Object>> list = dbManager.select();
		for (int i=0; i<list.size(); i++) {
			markerPointSearchFlag = true;
			favoriteCount++;
			ArrayList<Object> values = list.get(i);
			long id = Long.parseLong(values.get(0).toString());
			String name = values.get(1).toString();
			double latitude = Double.parseDouble(values.get(2).toString());
			double longitude = Double.parseDouble(values.get(3).toString());
			LatLng latLng = new LatLng(latitude, longitude);
			addFavorite(id, name, latLng);
		}
		
		// 웹뷰 설정
		webCamera.setWebChromeClient(new WebChromeClient());
		webCamera.loadUrl("http://" + CLIENT_IP + ":8080/stream_simple.html");
	}
	
	
	
	
	/****************************************
	 *******  맵 관련 메소드 & 리스너 *******
	 ****************************************/
	
	// 마커 생성
	private void createMarker(LatLng latLng, int what, boolean moveCenter) {
		
		// 마커 위치 설정
		switch (what) {
			case MARKER_POINT :
				markerPoint.position(latLng);
				break;
			case MARKER_MY_LOCATION :
				markerMyLocation.position(latLng);
				break;
			case MARKER_CAR :
				markerCar.position(latLng);
				break;
		}
		
		// 포인트, 내 위치, picar 위치에 대한 마커 생성
		mapView.clear();
		
		if (markerPointSearchFlag) {
			mapView.addMarker(markerPoint).showInfoWindow();
		}
		
		if (markerMyLocationSearchFlag) {
			mapView.addMarker(markerMyLocation);
		}
		
		if (markerCarSearchFlag) {
			mapView.addMarker(markerCar);
		}
		
		// 마커 생성위치로 카메라 이동
		if (moveCenter) {
			mapView.animateCamera(CameraUpdateFactory.newLatLng(latLng));
		}
	}
	
	// 위치 서비스 사용 설정 대화상자
	private void showSettingsDialog() {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
		alertDialog.setTitle("위치 서비스 사용 설정");
		alertDialog.setMessage("PiCar 지도에서 위치 정보를 사용하려면\n위치 서비스 권한을 허용해주세요.");
		
		alertDialog.setPositiveButton("설정", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
				startActivity(intent);
			}
		});
		
		alertDialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
				Toast.makeText(getApplicationContext(), "위치 서비스 미동의\n내 위치를 찾을 수 없습니다.", Toast.LENGTH_LONG).show();
			}
		});
		
		alertDialog.show();
	}
	
	// 위치 서비스 사용 설정
	private void checkGPSEnable() {
		boolean isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
		
		if (!isGPSEnabled) {
			showSettingsDialog();
		} else {
			if (!nMapLocationManager.isMyLocationEnabled()) {
				nMapLocationManager.enableMyLocation(true);
				nMapLocationManager.setOnLocationChangeListener(locationListener);
			}
		}
	}
	
	// 네이버맵 내 위치 위치 검색 이벤트
	private class MyLocationListener implements OnLocationChangeListener {
		@Override
		public boolean onLocationChanged(NMapLocationManager manager, NGeoPoint point) {
			markerMyLocationSearchFlag = true;
			LatLng latLng = new LatLng(point.getLatitude(), point.getLongitude());
			createMarker(latLng, MARKER_MY_LOCATION, markerMyLocationCenterFlag);
			markerMyLocationCenterFlag = false;
			
			return true; // true : 계속해서 내 위치 검색
		}

		@Override
		public void onLocationUnavailableArea(NMapLocationManager arg0,	NGeoPoint arg1) { }

		@Override
		public void onLocationUpdateTimeout(NMapLocationManager arg0) { }
	}
	
	// 마커 생성 이벤트
	private class GoogleMapMarkerEvent implements OnMapLongClickListener {
		@Override
		public void onMapLongClick(LatLng latLng) {
			// 마커 생성
			markerPointSearchFlag = true;
			createMarker(latLng, MARKER_POINT, true);

			// 즐겨찾기 추가
			long id = System.currentTimeMillis();
			String name = "포인트 " + favoriteCount++;
			addFavorite(id, name, latLng);;
			
			// DB 추가
			dbManager.insert(id, name, latLng.latitude, latLng.longitude);
		}
	}

	// 마커 말풍선 어댑터 (말풍선 커스텀) - 말풍선 == 이미지
	private class MarkerInfoWindowAdapter implements InfoWindowAdapter {
		@Override
		public View getInfoContents(Marker marker) {
			View v = inflater.inflate(R.layout.marker_info_window, (ViewGroup) findViewById(R.id.layout_info_window_root));
			return v;
		}

		@Override
		public View getInfoWindow(Marker marker) {
			return null;
		}
	}
	
	// 말풍선 클릭 이벤트 (PiCar 이동)
	private class InfoWindowClickEvent implements OnInfoWindowClickListener {
		@Override
		public void onInfoWindowClick(Marker marker) {
			// TODO
		}
	}
	
	
	
	
	/********************************
	 ******* 기타 버튼 이벤트 *******
	 ********************************/
	
	// 카메라 버튼 이벤트
	private class CameraButtonEvent implements OnClickListener {
		@Override
		public void onClick(View v) {
			isCamera = !isCamera;
			if (isCamera) {
				layoutMap.setVisibility(View.GONE);
				webCamera.setVisibility(View.VISIBLE);
				btnAdjust.setVisibility(View.GONE);
				btnCamera.setImageResource(R.drawable.btn_camera_on);
			}
			else {
				layoutMap.setVisibility(View.VISIBLE);
				webCamera.setVisibility(View.GONE);
				btnAdjust.setVisibility(View.VISIBLE);
				btnCamera.setImageResource(R.drawable.btn_camera_off);
				checkGPSEnable();
			}
		}
	}
	
	// 위치 보정 버튼 이벤트
	private class AdjustButtonEvent implements OnClickListener {
		@Override
		public void onClick(View v) {
			// TODO
		}
	}
	
	// 즐겨찾기 레이아웃 이벤트
	private class FavoriteLayoutEvent implements OnClickListener {
		@Override
		public void onClick(View v) {
			
		}
	}
	
	// 즐겨찾기 포인트 클릭 이벤트
	private class FavoriteButtonEvent implements OnClickListener {
		@Override
		public void onClick(View v) {
			RelativeLayout layout = (RelativeLayout) v;
			TextView textView = (TextView) layout.findViewById(R.id.textview_favorite_latlng);
			
			String s = textView.getText().toString(); // s == lat/lng: (lat,lng)
			s = s.split("\\(")[1];
			s = s.split("\\)")[0];
			double lat = Double.parseDouble(s.split(",")[0]);
			double lng = Double.parseDouble(s.split(",")[1]);
			LatLng latLng = new LatLng(lat, lng);

			// 마커 생성
			createMarker(latLng, MARKER_POINT, true);
		}
	}
	
	// 즐겨찾기 포인트 추가
	private void addFavorite(long id, String name, LatLng latLng) {
		// 즐겨찾기 추가
		@SuppressLint("InflateParams")
		View view = inflater.inflate(R.layout.favorite_list, null);
		
		TextView tv1 = (TextView) view.findViewById(R.id.textview_favorite_id);
		TextView tv2 = (TextView) view.findViewById(R.id.textview_favorite_name);
		TextView tv3 = (TextView) view.findViewById(R.id.textview_favorite_latlng);
		tv1.setText(String.valueOf(id));
		tv2.setText(name);
		tv3.setText(String.valueOf(latLng));

		// 해당 뷰 클릭 이벤트 
		view.setOnClickListener(new FavoriteButtonEvent());
		
		// 해당 뷰 제거 이벤트
		view.setOnLongClickListener(new OnLongClickListener() {
			@Override
			public boolean onLongClick(View view) {
				TextView tv1 = (TextView) view.findViewById(R.id.textview_favorite_id);
				TextView tv2 = (TextView) view.findViewById(R.id.textview_favorite_name);
				
				long id = Long.parseLong(tv1.getText().toString());
				String name = tv2.getText().toString();
				
				showRemoveFavoriteDialog(view, id, name);
				return false;
			}
		});
		
		layoutFavorite.addView(view);
	}
	
	// 즐겨찾기 포인트 대화상자
	private void showRemoveFavoriteDialog(final View view, final long id, final String name) {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
		alertDialog.setTitle("저장된 포인트 변경");
		alertDialog.setMessage("'" + name + "' 변경하시겠습니까?");
		
		alertDialog.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				view.setOnClickListener(null);
				view.setVisibility(View.GONE);
				dbManager.delete(id);
				Toast.makeText(getApplicationContext(), "'" + name + "' 삭제되었습니다.", Toast.LENGTH_SHORT).show();
			}
		});
		alertDialog.setNeutralButton("이름 변경", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
				showRenameFavoriteDialog(view, id, name);
			}
		});
		alertDialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
		
		alertDialog.show();
	}
	
	// 즐겨찾기 포인트 이름 변경 대화상자
	private void showRenameFavoriteDialog(final View view, final long id, final String name) {
		final EditText edit = new EditText(this);
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
		alertDialog.setTitle("'" + name + "' 이름 변경");
		alertDialog.setView(edit);
		
		alertDialog.setPositiveButton("확인", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				String changedName = edit.getText().toString();
				TextView tv1 = (TextView) view.findViewById(R.id.textview_favorite_name);
				tv1.setText(changedName);
				dbManager.update(id, changedName);
				Toast.makeText(getApplicationContext(), "'" + name + "' 에서 '" + changedName + "' 으로\n"
														+ "이름이 변경되었습니다.", Toast.LENGTH_SHORT).show();
			}
		});
		alertDialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
		
		alertDialog.show();
	}
	
	
	
	
	/**********************************
	 ******* PI CAR 제어 리스너 *******
	 **********************************/
	
	// 모터 제어 버튼 이벤트
	private class MotorControlButtonEvent implements OnTouchListener {
		@Override
		@SuppressLint("ClickableViewAccessibility")
		public boolean onTouch(View v, MotionEvent event) {
			byte[] message = new byte[] {PROTOCOL_MOTOR, MOTOR_STOP};
			
			switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					v.setPressed(true);
					
					switch (v.getId()) {
						case R.id.button_forward:
							message[1] = MOTOR_FORWARD;
							break;
						case R.id.button_left:
							message[1] = MOTOR_TURN_LEFT;
							break;
						case R.id.button_right:
							message[1] = MOTOR_TURN_RIGHT;
							break;
						case R.id.button_backward:
							message[1] = MOTOR_BACKWARD;
							break;
						case R.id.button_auto:
							message[1] = MOTOR_AUTO;
							break;
					}
					new Thread(new SendThread(message)).start();
					break;
					
				case MotionEvent.ACTION_UP:
					v.setPressed(false);
					if (v.getId() == R.id.button_auto) {
						isAuto = !isAuto;
						if (isAuto)
							v.setBackgroundResource(R.drawable.stop_btn_selector);
						else
							v.setBackgroundResource(R.drawable.auto_btn_selector);
					}
					new Thread(new SendThread(message)).start();
					new Thread(new SendThread(message)).start();
					break;
			}
			
			return false;
		}
	}
	
	// 모터 속도 제어 이벤트
	private class MotorSpeedControlEvent implements OnSeekBarChangeListener {

		int progress = 0;
		
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
			this.progress = progress;
		}

		@Override
		public void onStartTrackingTouch(SeekBar seekBar) { }

		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			byte value = Byte.parseByte(String.valueOf(progress+1));
			byte[] message = new byte[] {PROTOCOL_MOTOR, MOTOR_SPEED_CHANGE, value};
			new Thread(new SendThread(message)).start();
		}
	}
	
	
	
	
	/********************
	 ******* 통신 *******
	 ********************/

	// UDP 패킷 송신 쓰레드
	private class SendThread implements Runnable {
		
		private byte[] message;
		
		public SendThread(byte[] message) {
			this.message = message;
		}

		@Override
		public void run() {
			try {
				InetAddress address = InetAddress.getByName(CLIENT_IP);
				DatagramPacket packet = new DatagramPacket(message, message.length, address, CLIENT_PORT);
				clientSocket.send(packet);
			} catch (Exception e) {
				Log.d("UDP Socket", "Error", e);
			}
		}
		
	}
	
	// UDP 패킷 수신 태스크
	private class ReceiveTask extends AsyncTask<Void, Void, Void> {

		private byte[] buffer = new byte[50];
		
		@Override
		protected Void doInBackground(Void... params) {
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
			String msg;
			
			while (isRunning) {
				// 초기화
				msg = "";
				for (int i=0; i<buffer.length; i++) {
					buffer[i] = -1;
				}

				// 패킷 수신 후 문자열로 변환
				try {
					serverSocket.receive(packet);
					
					for (int i=0; i<buffer.length; i++) {
						if (buffer[i] == -1) {
							break;
						}
						char a = (char) buffer[i];
						msg += a;
					}

					double latitude = Double.parseDouble(msg.split(",")[0]);
					double longitude = Double.parseDouble(msg.split(",")[1]);
					
					if (!markerCarSearchFlag) {
						markerCarSearchFlag = true;
					}
					LatLng latLng = new LatLng(latitude, longitude);
					//createMarker(latLng, MARKER_CAR, false);
					isRunning = false;
					
					Log.d("ReceiveTask", "latitude : " + latitude + ", longitude : " + longitude);
				} catch (Exception e) {
					Log.d("ReceiveTask", "error", e);
				}
			}
			
			return null;
		}
	}
	
	
	
	
	/***********************
	 ******* 앱 제어 *******
	 ***********************/
	
	@Override
	protected void onResume() {
		markerMyLocationCenterFlag = true;
		if (receiveTask.isCancelled()) {
			receiveTask.execute(null, null, null);
		}
		isRunning = true;
		// showGPSEnable();
		super.onResume();
	}
	
	@Override
	protected void onDestroy() {
		nMapLocationManager.disableMyLocation();
		serverSocket.disconnect();
		clientSocket.disconnect();
		isRunning = false;
		receiveTask.cancel(true);
		serverSocket.close();
		clientSocket.close();
		super.onDestroy();
	}
}