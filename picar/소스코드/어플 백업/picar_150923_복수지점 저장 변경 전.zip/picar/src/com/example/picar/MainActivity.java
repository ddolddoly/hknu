package com.example.picar;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.nhn.android.maps.NMapLocationManager;
import com.nhn.android.maps.NMapLocationManager.OnLocationChangeListener;
import com.nhn.android.maps.maplib.NGeoPoint;

public class MainActivity extends FragmentActivity {

	// 통신 프로토콜
	private static final byte PROTOCOL_MOTOR = 'M';
	private static final byte PROTOCOL_GPS = 'G';
	
	
	// 모터 조종 프로토콜
	private static final byte MOTOR_FORWARD = 'F';
	private static final byte MOTOR_BACKWARD = 'B';
	private static final byte MOTOR_TURN_LEFT = 'L';
	private static final byte MOTOR_TURN_RIGHT = 'R';
	private static final byte MOTOR_STOP = 'S';
	private static final byte MOTOR_AUTO = 'A';
	private static final byte MOTOR_SPEED_CHANGE = 'P';
	
	
	// 메시지 프로토콜
	private static final int MESSAGE_GPS = 1;
	
	
	// 안전장치 쓰레드
	private SafetyThread safetyThread;
	
	
	// 마커 구분
	private static final byte MARKER_POINT = 0;
	private static final byte MARKER_ME = 1;
	private static final byte MARKER_CAR = 2;
	
	
	// 통신 변수
	private WifiManager wifiManager;
	private static String WIFI_IP = "0.0.0.0";
	private static String AP_IP = "0.0.0.0";
	private static final int WIFI_RECEIVE_PORT = 2049;
	private static final int AP_SEND_PORT = 2048;
	private DatagramSocket receiveSocket;
	private DatagramSocket sendSocket;
	private Thread receiveThread;
	private Handler receiveHandler;
	
	
	// 제어 변수
	private boolean isRunning = false;
	private boolean isAuto = false;
	private boolean isCamera = false;
	private boolean isMapLongClicked = false;
	private boolean isFavoriteClicked = false;
	private boolean isHelpClicked = false;
	private int favoriteCount = 1;
	private int motorSpeed = 5;
	
	
	// 맵
	private GoogleMap mapView;
	private NMapLocationManager nMapLocationManager;
	private MyLocationListener locationListener;
	private MarkerOptions markerPoint;
	private MarkerOptions markerMyLocation;
	private MarkerOptions markerCar;
	private LocationManager locationManager;
	// 맵 제어
	private boolean markerPointSearchFlag = false;
	private boolean markerMyLocationCenterFlag = false;
	private boolean markerMyLocationSearchFlag = false;
	private boolean markerCarSearchFlag = false;
	
	
	// DB
	private DBManager dbManager;
	
	
	// 콜렉션
	private ArrayList<LatLng> latLngList;
	
	
	// 뷰
	private WebView webCamera;
	private ImageButton btnCamera;
	private ImageButton btnAdjust;
	private ImageButton btnSpeedUp;
	private ImageButton btnSpeedDown;
	private ImageButton btnFavorite;
	private ImageButton btnHelp;
	private LayoutInflater inflater;
	private LinearLayout layoutMap;
	private LinearLayout layoutMapBottom;
	private RelativeLayout containerFavorite;
	private LinearLayout layoutFavorite;
	
	
	// 애니메이션
	private int[] controlAnimNormal;
	private int[] controlAnimPressed;
	private int controlAnimCounter = 0;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);


		
		/***************************
		 ******** 뷰 초기화 ********
		 ***************************/
		webCamera = (WebView) findViewById(R.id.webview_camera);
		btnCamera = (ImageButton) findViewById(R.id.button_camera);
		btnAdjust = (ImageButton) findViewById(R.id.button_adjust);
		btnSpeedUp = (ImageButton) findViewById(R.id.button_speed_up);
		btnSpeedDown = (ImageButton) findViewById(R.id.button_speed_down);
		btnFavorite = (ImageButton) findViewById(R.id.button_favorite);
		btnHelp = (ImageButton) findViewById(R.id.button_help);
		layoutMap = (LinearLayout) findViewById(R.id.layout_map);
		layoutMapBottom = (LinearLayout) findViewById(R.id.layout_map_bottom);
		containerFavorite = (RelativeLayout) findViewById(R.id.container_favorite);
		layoutFavorite = (LinearLayout) findViewById(R.id.layout_favorite);
		
		Button btnFavoriteSave = (Button) findViewById(R.id.button_favorite_save);
		Button btnForward = (Button) findViewById(R.id.button_forward);
		Button btnLeft = (Button) findViewById(R.id.button_left);
		Button btnRight = (Button) findViewById(R.id.button_right);
		Button btnBackward = (Button) findViewById(R.id.button_backward);
		ImageButton btnAuto = (ImageButton) findViewById(R.id.button_auto_image);

		mapView = ((SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.map)).getMap();
		

		
		/**********************************
		 ******** 뷰 이벤트 바인딩 ********
		 **********************************/
		btnCamera.setOnClickListener(new CameraButtonEvent());
		btnAdjust.setOnClickListener(new AdjustButtonEvent());
		btnSpeedUp.setOnClickListener(new MotorSpeedControlEvent());
		btnSpeedDown.setOnClickListener(new MotorSpeedControlEvent());
		btnFavorite.setOnClickListener(new FavoriteButtonEvent());
		btnHelp.setOnClickListener(new HelpButtonEvent());
		btnFavoriteSave.setOnClickListener(new FavoriteSaveEvent());
		btnForward.setOnTouchListener(new MotorControlButtonEvent());
		btnLeft.setOnTouchListener(new MotorControlButtonEvent());
		btnRight.setOnTouchListener(new MotorControlButtonEvent());
		btnBackward.setOnTouchListener(new MotorControlButtonEvent());
		btnAuto.setOnTouchListener(new MotorControlButtonEvent());
		
		mapView.setOnMapClickListener(new GoogleMapClickEvent());
		mapView.setOnMapLongClickListener(new GoogleMapMarkerEvent());
		mapView.setInfoWindowAdapter(new MarkerInfoWindowAdapter());
		mapView.setOnInfoWindowClickListener(new InfoWindowClickEvent());
		mapView.setOnMarkerClickListener(new OnMarkerClickListener() {
			@Override
			public boolean onMarkerClick(Marker marker) {
				return true; // true : 구글 마커의 default control off
			}
		});
		
		
		
		/****************************
		 ******* 기타 초기화 ********
		 ****************************/
		init();
	}
	
	
	// 초기화
	@SuppressLint({ "DefaultLocale", "HandlerLeak" })
	private void init() {
		
		/*************************
		 ******* 통신 설정 *******
		 *************************/
		// IP 얻어오기
		wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
		DhcpInfo dhcpInfo = wifiManager.getDhcpInfo();
		
		// 접속한 AP의 IP
		int client = dhcpInfo.gateway;
		AP_IP = String.format("%d.%d.%d.%d", client & 0xff, client >> 8 & 0xff, client >> 16 & 0xff, client >> 24 & 0xff);
		// AP_IP = "10.0.0.4"; //TODO
		Log.d("IP Address", "AP IP : " + AP_IP);
		
		// 단말기의 WIFI IP
		int server = dhcpInfo.ipAddress;
		WIFI_IP = String.format("%d.%d.%d.%d", server & 0xff, server >> 8 & 0xff, server >> 16 & 0xff, server >> 24 & 0xff);
		Log.d("IP Address", "WIFI IP : " + WIFI_IP);
		
		// UDP 소켓 생성
		try {
			InetAddress address = InetAddress.getByName(WIFI_IP);
			receiveSocket = new DatagramSocket(WIFI_RECEIVE_PORT, address);
			sendSocket = new DatagramSocket();
		} catch (Exception e) {
			Log.d("UDP Socket", "Create Error", e);
		}
		
		// UDP 패킷 수신 쓰레드
		isRunning = true;
		receiveThread = new ReceiveThread();
		receiveHandler = new ReceiveHandler();
		receiveThread.start();
		
		
		
		/**************************
		 ******** 맵 설정 *********
		 **************************/
		// 맵 시작위치 설정
		LatLng startPoint = new LatLng(37.01129, 127.26420); // 학교
		mapView.moveCamera(CameraUpdateFactory.newLatLngZoom(startPoint, 17));
		
		// 마커 설정
		markerPoint = new MarkerOptions();
		markerMyLocation = new MarkerOptions();
		markerCar = new MarkerOptions();
		markerPoint.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_point));
		markerMyLocation.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_me));
		markerCar.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_car));
		markerMyLocationCenterFlag = true; // 최초 호출 시 내 위치로 이동
		
		// GPS 설정... 내 위치 검색은 네이버맵 API 이용
		nMapLocationManager = new NMapLocationManager(getApplicationContext());
		locationListener = new MyLocationListener();
        locationManager = (LocationManager) this.getSystemService(LOCATION_SERVICE);
        checkGPSEnable();
        
        
		
        /*************************
         ******* 기타 설정 *******
         *************************/
		inflater = getLayoutInflater();
		
		// 안전장치 쓰레드 할당
		safetyThread = new SafetyThread();
		safetyThread.start();
		
		// db 설정
		dbManager = new DBManager(this, "point.db", null, 1);
		
		// 콜렉션 초기화
		latLngList = new ArrayList<LatLng>();
		
		// 저장된 즐겨찾기 포인트 불러오기
		ArrayList<ArrayList<Object>> list = dbManager.select();
		for (int i=0; i<list.size(); i++) {
			favoriteCount++;
			ArrayList<Object> values = list.get(i);
			long id = Long.parseLong(values.get(0).toString());
			String name = values.get(1).toString();
			double latitude = Double.parseDouble(values.get(2).toString());
			double longitude = Double.parseDouble(values.get(3).toString());
			LatLng latLng = new LatLng(latitude, longitude);
			addFavorite(id, name, latLng);
		}
		
		// 웹뷰 설정
		webCamera.setWebChromeClient(new WebChromeClient());
		webCamera.loadUrl("http://" + AP_IP + ":8080/stream_simple.html");
		
		// 애니메이션 설정
		controlAnimNormal = new int[] {R.drawable.btn_control_normal_1, R.drawable.btn_control_normal_2, R.drawable.btn_control_normal_3};
		controlAnimPressed = new int[] {R.drawable.btn_control_pressed_1, R.drawable.btn_control_pressed_2, R.drawable.btn_control_pressed_3};
	}
	
	
	
	
	/****************************************
	 *******  맵 관련 메소드 & 리스너 *******
	 ****************************************/
	
	// 마커 생성
	private void createMarker(LatLng latLng, int what, boolean moveCenter) {
		
		// 마커 위치 설정
		switch (what) {
		case MARKER_POINT :
			markerPoint.position(latLng);
			break;
		case MARKER_ME :
			markerMyLocation.position(latLng);
			break;
		case MARKER_CAR :
			markerCar.position(latLng);
			break;
		}
		
		// 포인트, 내 위치, picar 위치에 대한 마커 생성
		mapView.clear();
		
		if (markerPointSearchFlag) {
			mapView.addMarker(markerPoint).showInfoWindow();
		}
		
		if (markerMyLocationSearchFlag) {
			mapView.addMarker(markerMyLocation);
		}
		
		if (markerCarSearchFlag) {
			mapView.addMarker(markerCar);
		}
		
		// 마커 생성위치로 카메라 이동
		if (moveCenter) {
			mapView.animateCamera(CameraUpdateFactory.newLatLng(latLng));
		}
	}
	
	// 위치 서비스 사용 설정 대화상자
	private void showSettingsDialog() {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
		alertDialog.setTitle("위치 서비스 사용 설정");
		alertDialog.setMessage("PiCar 지도에서 위치 정보를 사용하려면\n위치 서비스 권한을 허용해주세요.");
		
		alertDialog.setPositiveButton("설정", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
				startActivity(intent);
			}
		});
		
		alertDialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
				Toast.makeText(getApplicationContext(), "위치 서비스 미동의\n내 위치를 찾을 수 없습니다.", Toast.LENGTH_LONG).show();
			}
		});
		
		alertDialog.show();
	}
	
	// 위치 서비스 사용 설정
	private void checkGPSEnable() {
		boolean isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
		
		if (!isGPSEnabled) {
			showSettingsDialog();
		} else {
			if (!nMapLocationManager.isMyLocationEnabled()) {
				nMapLocationManager.enableMyLocation(true);
				nMapLocationManager.setOnLocationChangeListener(locationListener);
			}
		}
	}
	
	// 네이버맵 내 위치 위치 검색 이벤트
	private class MyLocationListener implements OnLocationChangeListener {
		@Override
		public boolean onLocationChanged(NMapLocationManager manager, NGeoPoint point) {
			markerMyLocationSearchFlag = true;
			LatLng latLng = new LatLng(point.getLatitude(), point.getLongitude());
			createMarker(latLng, MARKER_ME, markerMyLocationCenterFlag);
			markerMyLocationCenterFlag = false;
			
			return true; // true : 계속해서 내 위치 검색
		}

		@Override
		public void onLocationUnavailableArea(NMapLocationManager arg0,	NGeoPoint arg1) { }

		@Override
		public void onLocationUpdateTimeout(NMapLocationManager arg0) { }
	}
	
	// 구글맵 클릭 이벤트
	private class GoogleMapClickEvent implements OnMapClickListener {
		@Override
		public void onMapClick(LatLng latLng) {
			if (isMapLongClicked) {
				Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.layout_map_bottom_gone);
				layoutMapBottom.startAnimation(animation);
				layoutMapBottom.setVisibility(View.GONE);
				isMapLongClicked = false;
			}
		}
	}
	
	// 마커 생성 이벤트
	private class GoogleMapMarkerEvent implements OnMapLongClickListener {
		@Override
		public void onMapLongClick(LatLng latLng) {
			// 마커 생성
			markerPointSearchFlag = true;
			createMarker(latLng, MARKER_POINT, true);
			
			// 맵 하단부 오픈
			isMapLongClicked = true;
			layoutMapBottom.setVisibility(View.VISIBLE);
			Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.layout_map_bottom_visible);
			layoutMapBottom.startAnimation(animation);

			// TODO
			// 콜렉션 추가
			latLngList.add(latLng);
		}
	}

	// 마커 말풍선 어댑터 (말풍선 커스텀) - 말풍선 == 이미지
	private class MarkerInfoWindowAdapter implements InfoWindowAdapter {
		@Override
		public View getInfoContents(Marker marker) {
			View v = inflater.inflate(R.layout.marker_info_window, (ViewGroup) findViewById(R.id.layout_info_window_root));
			return v;
		}

		@Override
		public View getInfoWindow(Marker marker) {
			return null;
		}
	}
	
	// 말풍선 클릭 이벤트 (PiCar 이동)
	private class InfoWindowClickEvent implements OnInfoWindowClickListener {
		@Override
		public void onInfoWindowClick(Marker marker) {
			if (markerCarSearchFlag) {
				// 마커의 좌표
				LatLng latLng = marker.getPosition();
				double lat = latLng.latitude;
				double lng = latLng.longitude;
				String sLat = Double.toString(lat);
				String sLng = Double.toString(lng);
				
				// 임시 메시지 작성
				byte[] temp = new byte[50];
				temp[0] = PROTOCOL_GPS;
				
				for (int i=0; i<sLat.length(); i++) {
					temp[i+1] = (byte) sLat.charAt(i);
				}
				
				temp[sLat.length()+1] = '/';
				for (int i=0; i<sLng.length(); i++) {
					temp[i+sLat.length()+2] = (byte) sLng.charAt(i);
				}
				
				// 메시지 크기 조절
				byte[] message = new byte[sLat.length()+sLng.length()+2];
				for (int i=0; i<message.length; i++) {
					message[i] = temp[i];
				}
				
				// 전송
				safetyThread.setFlag(false);
				new SendThread(message).start();
			} else {
				Toast.makeText(getApplicationContext(), "PiCar가 GPS 신호를 받을 수 없습니다.", Toast.LENGTH_SHORT).show();
			}
		}
	}
	
	
	
	
	/********************************
	 ******* 기타 버튼 이벤트 *******
	 ********************************/
	
	// 카메라 버튼 이벤트
	private class CameraButtonEvent implements OnClickListener {
		@Override
		public void onClick(View v) {
			isCamera = !isCamera;
			if (isCamera) {
				layoutMap.setVisibility(View.GONE);
				webCamera.setVisibility(View.VISIBLE);
				webCamera.loadUrl("http://" + AP_IP + ":8080/stream_simple.html");
				btnCamera.setImageResource(R.drawable.btn_camera_on);
			}
			else {
				layoutMap.setVisibility(View.VISIBLE);
				webCamera.setVisibility(View.GONE);
				btnCamera.setImageResource(R.drawable.btn_camera_off);
				checkGPSEnable();
			}
		}
	}
	
	// 위치 보정 버튼 이벤트
	private class AdjustButtonEvent implements OnClickListener {
		@Override
		public void onClick(View v) {

		}
	}
	
	// 도움말 버튼 이벤트
	private class HelpButtonEvent implements OnClickListener {
		@Override
		public void onClick(View v) {
			isHelpClicked = !isHelpClicked;
			if (isHelpClicked) {
				btnHelp.setBackgroundResource(R.drawable.btn_help_c);
			} else {
				btnHelp.setBackgroundResource(R.drawable.btn_help);
			}
		}
	}
	
	// 즐겨찾기 버튼 이벤트
	private class FavoriteButtonEvent implements OnClickListener {
		@Override
		public void onClick(View v) {
			isFavoriteClicked = !isFavoriteClicked;
			if (isFavoriteClicked) {
				btnFavorite.setBackgroundResource(R.drawable.btn_favorite_c);
				containerFavorite.setVisibility(View.VISIBLE);
				Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.container_favorite_visible);
				containerFavorite.startAnimation(animation);
			} else {
				btnFavorite.setBackgroundResource(R.drawable.btn_favorite);
				Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.container_favorite_gone);
				containerFavorite.startAnimation(animation);
				containerFavorite.setVisibility(View.GONE);
			}
		}
	}
	
	// 즐겨찾기 포인트 클릭 이벤트
	private class FavoriteLayoutEvent implements OnClickListener {
		@Override
		public void onClick(View v) {
			RelativeLayout layout = (RelativeLayout) v;
			TextView textView = (TextView) layout.findViewById(R.id.textview_favorite_latlng);
			
			String s = textView.getText().toString(); // s == lat/lng: (lat,lng)
			s = s.split("\\(")[1];
			s = s.split("\\)")[0];
			double lat = Double.parseDouble(s.split(",")[0]);
			double lng = Double.parseDouble(s.split(",")[1]);
			LatLng latLng = new LatLng(lat, lng);

			// 마커 생성
			markerPointSearchFlag = true;
			createMarker(latLng, MARKER_POINT, true);
		}
	}
	
	// 즐겨찾기 저장 클릭 이벤트
	private class FavoriteSaveEvent implements OnClickListener {
		@Override
		public void onClick(View v) {
			// TODO
			long id = System.currentTimeMillis();
			String name = "포인트 " + favoriteCount;
			
			LatLng latLng = null;
			for (int i=0; i<latLngList.size(); i++) {
				latLng = latLngList.get(i);
				
				// DB 추가
				dbManager.insert(id, name, latLng.latitude, latLng.longitude);
			}
			
			// 즐겨찾기 추가
			addFavorite(id, name, latLng);;
			
			favoriteCount++;
		}
	}
	
	// 즐겨찾기 포인트 추가
	private void addFavorite(long id, String name, LatLng latLng) {
		// 즐겨찾기 추가
		@SuppressLint("InflateParams")
		View view = inflater.inflate(R.layout.favorite_list, null);
		
		TextView tv1 = (TextView) view.findViewById(R.id.textview_favorite_id);
		TextView tv2 = (TextView) view.findViewById(R.id.textview_favorite_name);
		TextView tv3 = (TextView) view.findViewById(R.id.textview_favorite_latlng);
		tv1.setText(String.valueOf(id));
		tv2.setText(name);
		tv3.setText(String.valueOf(latLng));

		// 해당 뷰 클릭 이벤트 
		view.setOnClickListener(new FavoriteLayoutEvent());
		
		// 해당 뷰 제거 이벤트
		view.setOnLongClickListener(new OnLongClickListener() {
			@Override
			public boolean onLongClick(View view) {
				TextView tv1 = (TextView) view.findViewById(R.id.textview_favorite_id);
				TextView tv2 = (TextView) view.findViewById(R.id.textview_favorite_name);
				
				long id = Long.parseLong(tv1.getText().toString());
				String name = tv2.getText().toString();
				
				showRemoveFavoriteDialog(view, id, name);
				return false;
			}
		});
		
		layoutFavorite.addView(view);
	}
	
	// 즐겨찾기 포인트 대화상자
	private void showRemoveFavoriteDialog(final View view, final long id, final String name) {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
		alertDialog.setTitle("저장된 포인트 변경");
		alertDialog.setMessage("'" + name + "' 변경하시겠습니까?");
		
		alertDialog.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				view.setOnClickListener(null);
				view.setVisibility(View.GONE);
				dbManager.delete(id);
				Toast.makeText(getApplicationContext(), "'" + name + "' 삭제되었습니다.", Toast.LENGTH_SHORT).show();
			}
		});
		alertDialog.setNeutralButton("이름 변경", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
				showRenameFavoriteDialog(view, id, name);
			}
		});
		alertDialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
		
		alertDialog.show();
	}
	
	// 즐겨찾기 포인트 이름 변경 대화상자
	private void showRenameFavoriteDialog(final View view, final long id, final String name) {
		final EditText edit = new EditText(this);
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
		alertDialog.setTitle("'" + name + "' 이름 변경");
		alertDialog.setView(edit);
		
		alertDialog.setPositiveButton("확인", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				String changedName = edit.getText().toString();
				TextView tv1 = (TextView) view.findViewById(R.id.textview_favorite_name);
				tv1.setText(changedName);
				dbManager.update(id, changedName);
				Toast.makeText(getApplicationContext(), "'" + name + "' 에서 '" + changedName + "' 으로\n"
														+ "이름이 변경되었습니다.", Toast.LENGTH_SHORT).show();
			}
		});
		alertDialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
		
		alertDialog.show();
	}
	
	
	
	
	/***************************
	 ******* PI CAR 제어 *******
	 ***************************/
	
	// 모터 제어 버튼 이벤트
	private class MotorControlButtonEvent implements OnTouchListener {
		
		private View animView;
		private Animation anim;
		
		@Override
		@SuppressLint("ClickableViewAccessibility")
		public boolean onTouch(View v, MotionEvent event) {
			byte[] message = new byte[] {PROTOCOL_MOTOR, MOTOR_STOP};
			
			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				if (v.getId() == R.id.button_auto_image) {
					message[1] = MOTOR_AUTO;
				} else {
					switch (v.getId()) {
					case R.id.button_forward:
						animView = findViewById(R.id.button_forward_animation);
						message[1] = MOTOR_FORWARD;
						break;
					case R.id.button_left:
						animView = findViewById(R.id.button_left_animation);
						message[1] = MOTOR_TURN_LEFT;
						break;
					case R.id.button_right:
						animView = findViewById(R.id.button_right_animation);
						message[1] = MOTOR_TURN_RIGHT;
						break;
					case R.id.button_backward:
						animView = findViewById(R.id.button_backward_animation);
						message[1] = MOTOR_BACKWARD;
						break;
					}
					
					if (animView != null) {
						animView.clearAnimation();
						animView.setBackgroundResource(controlAnimNormal[controlAnimCounter]);
						animView.setPressed(true);
						anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.btn_control_alpha);
						anim.setAnimationListener(new MotorControlButtonAnimation(animView, controlAnimCounter++));
						controlAnimCounter %= 3;
					}
				}
				safetyThread.setFlag(false);
				new SendThread(message).start();
				break;
				
			case MotionEvent.ACTION_UP:
				if (v.getId() == R.id.button_auto_image) {
					isAuto = !isAuto;
					if (isAuto)
						v.setBackgroundResource(R.drawable.btn_stop_selector);
					else
						v.setBackgroundResource(R.drawable.btn_auto_selector);
				} else {
					animView.startAnimation(anim);
				}

				safetyThread.setFlag(false);
				safetyThread = new SafetyThread();
				safetyThread.start();
				break;
			}
			
			return false;
		}
	}
	
	// 모터 속도 제어 이벤트
	private class MotorSpeedControlEvent implements OnClickListener {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.button_speed_up :
				if (motorSpeed < 9) {
					motorSpeed++;
				}
				break;
			case R.id.button_speed_down :
				if (motorSpeed > 1) {
					motorSpeed--;
				}
				break;
			}

			Toast.makeText(getApplicationContext(), "현재 속도 : " + motorSpeed + " / 9", Toast.LENGTH_SHORT).show();
			
			byte value = (byte) (motorSpeed + 48);
			byte[] message = new byte[] {PROTOCOL_MOTOR, MOTOR_SPEED_CHANGE, value};
			new SendThread(message).start();
		}
	}
	
	// 안전장치 쓰레드 - 모터 제어 신호가 없는 동안에는 2초마다 정지 신호 송신
	private class SafetyThread extends Thread implements Runnable {
		
		private boolean flag = true;
		
		@Override
		public void run() {
			byte[] message = null;

			while (flag) {
				try {
					message = new byte[] {PROTOCOL_MOTOR, MOTOR_STOP};
					new SendThread(message).start();
					Thread.sleep(2000);
				} catch (Exception e) {
					
				}
			}
		}
		
		public void setFlag(boolean flag) {
			this.flag = flag;
		}
	}
	
	
	
	
	/********************
	 ******* 통신 *******
	 ********************/

	// UDP 패킷 송신 쓰레드
	private class SendThread extends Thread implements Runnable {
		
		private byte[] message;
		
		public SendThread(byte[] message) {
			this.message = message;
		}

		@Override
		public void run() {
			try {
				InetAddress address = InetAddress.getByName(AP_IP);
				DatagramPacket packet = new DatagramPacket(message, message.length, address, AP_SEND_PORT);
				sendSocket.send(packet);
				Log.d("SendThread", "send packet : " + Arrays.toString(byteToChar(packet.getData())));
			} catch (Exception e) {
				Log.d("UDP Socket", "Error", e);
			}
		}
		
		private char[] byteToChar(byte[] in) {
			char[] out = new char[in.length];
			
			for (int i=0; i<in.length; i++) {
				out[i] = (char) in[i];
			}
			
			return out;
		}
	}

	// UDP 패킷 수신 쓰레드
	private class ReceiveThread extends Thread implements Runnable {
		
		byte[] buffer = new byte[50];

		@Override
		public void run() {
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
			String receiveString;
			
			while (isRunning) {
				
				// 초기화
				receiveString = "";
				for (int i=0; i<buffer.length; i++) {
					buffer[i] = -1;
				}

				// 패킷 수신 후 문자열로 변환
				try {
					receiveSocket.receive(packet);
					
					for (int i=0; i<buffer.length; i++) {
						if (buffer[i] == -1) {
							break;
						}
						char a = (char) buffer[i];
						receiveString += a;
					}

					// 핸들러로 메시지 전송
					Message msg = receiveHandler.obtainMessage();
					msg.what = MESSAGE_GPS;
					msg.obj = receiveString;
					receiveHandler.sendMessage(msg);
					Log.d("ReceiveTask", receiveString);
				} catch (Exception e) {
					Log.d("ReceiveTask", "error", e);
				}
			}
		}
	}
	
	// UDP 패킷 수신 핸들러 : 수신 쓰레드 → 핸들러 → 메인 쓰레드로 메시지 전달
	@SuppressLint("HandlerLeak")
	private class ReceiveHandler extends Handler {
		@Override
		public void handleMessage(Message msg) {
			// 수신받은 메시지에서 좌표 추출
			switch (msg.what) {
			case MESSAGE_GPS:
				String receiveString = String.valueOf(msg.obj);
				if (!"".equals(receiveString)) {
					double latitude = Double.parseDouble(receiveString.split(",")[0]);
					double longitude = Double.parseDouble(receiveString.split(",")[1]);
					LatLng latLng = new LatLng(latitude, longitude);
					
					// 지도에 마커 생성
					markerCarSearchFlag = true;
					createMarker(latLng, MARKER_CAR, false);
				}
				break;
			}

			super.handleMessage(msg);
		}
	}
	
	
	
	
	/**************************
	 ******* 애니메이션 *******
	 **************************/
	
	// 모터 제어 버튼 애니메이션
	private class MotorControlButtonAnimation implements AnimationListener {
		
		View v;
		private int count;
		
		public MotorControlButtonAnimation(View v, int count) {
			this.v = v;
			this.count = count;
		}

		@Override
		public void onAnimationEnd(Animation animation) {
			v.setBackgroundResource(controlAnimNormal[count]);
		}

		@Override
		public void onAnimationRepeat(Animation animation) { }

		@Override
		public void onAnimationStart(Animation animation) {
			v.setPressed(false);
			v.setBackgroundResource(controlAnimPressed[count++]);
			count %= 3;
		}
	}
	
	
	
	
	/***********************
	 ******* 앱 제어 *******
	 ***********************/
	
	@Override
	protected void onResume() {
		markerMyLocationCenterFlag = true;
		if (receiveThread.isInterrupted()) {
			receiveThread.start();
		}
		isRunning = true;
		safetyThread.setFlag(true);
		super.onResume();
	}
	
	@Override
	protected void onDestroy() {
		nMapLocationManager.disableMyLocation();
		receiveSocket.disconnect();
		sendSocket.disconnect();
		isRunning = false;
		safetyThread.setFlag(false);
		receiveThread.interrupt();
		receiveSocket.close();
		sendSocket.close();
		super.onDestroy();
	}
}