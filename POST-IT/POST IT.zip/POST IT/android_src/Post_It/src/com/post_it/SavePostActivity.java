package com.post_it;

import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class SavePostActivity extends Activity {
	
	static Activity mActivity;
	boolean Background_App = false;
	SharedPreferences preference_memo;
	
	ListView list_view;
	String[] list_str;
	
	// 화면이 표출되면 호출되는 onResume 
	@Override
	public void onResume() {
		super.onResume();
		if (Background_App) {
			Lock();
		}
		
		if (preference_memo.getString("list", "").length() == 0) {
	    	list_str = null;
	    } else {
	    	list_str = preference_memo.getString("list", "").split(",");
	    }
	    list_view.setAdapter(new ListAdapter());
	}

	// 화면이 사라지면 호출되는 onPause
	@Override
	public void onPause() {
	    super.onPause();
	    Background_App = isApplicationBroughtToBackground();
	}
		
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_savepost);
	    
	    mActivity = this;
	    
	    preference_memo = this.getSharedPreferences("Memo", Context.MODE_PRIVATE);
	    	    
	    if (preference_memo.getString("list", "").length() == 0) {
	    	list_str = null;
	    } else {
	    	list_str = preference_memo.getString("list", "").split(",");
	    }
	   
	    list_view = (ListView) this.findViewById(R.id.list_view);
	    list_view.setAdapter(new ListAdapter());
	
	    list_view.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Intent modify_post = new Intent(SavePostActivity.this, ModifyPostItEditActivity.class);
				modify_post.putExtra("key", list_str[position]);
				startActivity(modify_post);
			}
	    });
	}
	
	class ListAdapter extends BaseAdapter {
		
		LinearLayout layout;
		TextView del_date, memo_text, alarm_date;
		
		@Override
		public int getCount() {
			if (list_str == null) {
				return 0;
			} else {
				return list_str.length;
			}
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = inflater.inflate(R.layout.adapter_postit, parent, false);
			}
			
			layout = (LinearLayout) convertView.findViewById(R.id.layout);
			del_date = (TextView) convertView.findViewById(R.id.del_date);
			memo_text = (TextView) convertView.findViewById(R.id.memo_text);
			alarm_date = (TextView) convertView.findViewById(R.id.alarm_date);
			
			switch(preference_memo.getInt(list_str[position] + "_color", 0)) {
			case 0:
				layout.setBackgroundColor(Color.parseColor("#FFE400"));
				break;
			case 1:
				layout.setBackgroundColor(Color.parseColor("#00D8FF"));
				break;
			case 2:
				layout.setBackgroundColor(Color.parseColor("#FFD9FA"));
				break;
			case 3:
				layout.setBackgroundColor(Color.parseColor("#CEF279"));
				break;
			case 4:
				layout.setBackgroundColor(Color.parseColor("#FFA7A7"));
				break;
			}
			
			del_date.setText(preference_memo.getString(list_str[position] + "_deltime", "")+" 까지 저장됨");
			alarm_date.setText(preference_memo.getString(list_str[position] + "_alarmtime", ""));
			memo_text.setText(preference_memo.getString(list_str[position] + "_memo", ""));
			
			return convertView;
		}
		
	}
	
	// 잠금화면
	public void Lock() {
		Intent lock_view = new Intent(this, LockActivity.class);
		lock_view.putExtra("setting", false);
		lock_view.putExtra("restart", true);
		startActivity(lock_view);
	}
		
	// 어플이 백그라운드인지 포그라운드인지를 확인
	private boolean isApplicationBroughtToBackground() {
	    ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
	    List<RunningTaskInfo> tasks = am.getRunningTasks(1);
	    if (!tasks.isEmpty()) {
	        ComponentName topActivity = tasks.get(0).topActivity;
	        if (!topActivity.getPackageName().equals(getPackageName())) {
	            return true;
	        }
	    }
	    return false;
	}
}
