package com.post_it;

import java.text.ParseException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class PostItEditActivity extends Activity implements OnClickListener {
	
	static Activity mActivity;
	boolean Background_App = false;
	private Timer save_timer;
	
	POST_UTIL post_util;
	String Save_Key;
	
	EditText edit_text;
	Button color_btn, time_btn, home_btn, save_btn, cancel_btn, alarm_btn;
	ScrollView scrollView1;
	TextView time_text, time_alarm_text;

	
	// 화면이 표출되면 호출되는 onResume 
	@Override
	public void onResume() {
		super.onResume();
		if (Background_App) {
			Lock();
		}
	}

	// 화면이 사라지면 호출되는 onPause
	@Override
	public void onPause() {
	    super.onPause();
	    Background_App = isApplicationBroughtToBackground();
	}
	
	// Activity 완전 종료시 호출
	@Override
	public void onDestroy(){
		super.onDestroy();
		if (save_timer != null) {
			save_timer.cancel();
			save_timer = null;
		}
	}
	
	// timer 실행시 호출
	public class SaveTimerTask extends TimerTask {
		@Override
		public void run() {
			if(edit_text.getText().toString().trim().length() != 0) {
				Save(false);
			}
		}
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_postedit);
	    
	    mActivity = this;	 
	    post_util = new POST_UTIL(this);
	    
	    color_btn = (Button) this.findViewById(R.id.color_btn);
	    time_btn = (Button) this.findViewById(R.id.time_btn);
	    home_btn = (Button) this.findViewById(R.id.home_btn);
	    save_btn = (Button) this.findViewById(R.id.save_btn);
	    cancel_btn = (Button) this.findViewById(R.id.cancel_btn);
	    alarm_btn = (Button) this.findViewById(R.id.alarm_btn);
	    
	    scrollView1 = (ScrollView) this.findViewById(R.id.scrollView1);
	    time_text = (TextView) this.findViewById(R.id.time_text);
	    time_alarm_text = (TextView) this.findViewById(R.id.time_alarm_text);
	    
	    color_btn.setOnClickListener(this);
	    time_btn.setOnClickListener(this);
	    home_btn.setOnClickListener(this);
	    save_btn.setOnClickListener(this);
	    cancel_btn.setOnClickListener(this);
	    alarm_btn.setOnClickListener(this);
	    
	    Save_Key = post_util.Key_new(time_text, time_alarm_text, scrollView1);
	    
	    edit_text = (EditText) this.findViewById(R.id.editText1);
	    edit_text.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

			@Override
			public void afterTextChanged(Editable s) {}
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				if (save_timer != null) {
					save_timer.cancel();
					save_timer = null;
				}
				
				// Text창이 움직이지 않을 경우 글자가있으면 자동저장 시작 설정한 시간만큰 지난후에 스케쥴을 시작한다.
				if(edit_text.getText().toString().trim().length() != 0) {
					save_timer = new Timer(false);
				    int save_time_int = post_util.getSave_time()*60000;
					save_timer.schedule(new SaveTimerTask(), save_time_int);
				}
			}
	    });
	}
	
	@Override
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.color_btn: // 칼라 선택
			post_util.Color_Select(scrollView1);
			break;
		case R.id.time_btn: // 삭제 시간 선택
			post_util.Time_Select(time_text);
			break;
		case R.id.save_btn: // 저장버튼
			Save(true); // 버튼을 눌러서 저장할 경우 true
			break;
		case R.id.home_btn: // 홈버튼
			finish();
			break;
		case R.id.cancel_btn: // 취소버튼 (삭제)
			post_util.ondel(Save_Key);
			break;
		case R.id.alarm_btn: // 알람 설정버튼
			post_util.Alarm_Select(time_alarm_text);
			break;
		}
	}
	
	// 저장하기
	public void Save(boolean save_btn) {
		try {
			int result = post_util.Save_Verify(); // 유효성에 맞는지를 확인하여 코드를 가져온다. 0일때만 정상
			if (result == 0) { // 정상일경우
				if(edit_text.getText().toString().trim().length() != 0) {
					if (save_btn) {
						post_util.Key_save(Save_Key, edit_text.getText().toString(), time_alarm_text.getText().toString());
						Toast.makeText(getApplicationContext(), "저장되었습니다.", Toast.LENGTH_SHORT).show();
						finish();
					} else {
						this.runOnUiThread(new Runnable() {
						    public void run() {
						    	post_util.Key_save(Save_Key, edit_text.getText().toString(), time_alarm_text.getText().toString());
						    	Save_Key = post_util.Key_new(time_text, time_alarm_text, scrollView1);
						    	edit_text.setText("");
						    	Toast.makeText(getApplicationContext(), "저장되었습니다. 보관함을 확인하세요.", Toast.LENGTH_SHORT).show();
						    }
						});
					}
				} else {
					post_util.Key_del(Save_Key);
					finish();
				}
			} else { // 저장에 유효하지 않으면 알람을 띠운다. 자동저장일경우 토스트를 띠워서 사용한다.
				if (save_btn) {
					String alert_str = "삭제 시간이 현제 시간보다 전입니다.";
					if (result == 2) {
						alert_str = "알람 시간이 현제 시간보다 전입니다.";
					} else if (result == 3) {
						alert_str = "삭제 시간이 알람 시간보다 전입니다.";
					}
					AlertDialog.Builder builder = new AlertDialog.Builder(PostItEditActivity.this);
					builder.setTitle(alert_str)
					.setPositiveButton("확인", null).show();
				} else {
					this.runOnUiThread(new Runnable() {
					    public void run() {
					    	Toast.makeText(getApplicationContext(), "자동저장 실패 : 시간설정", Toast.LENGTH_SHORT).show();
					    }
					});
				}
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	// 잠금화면
	public void Lock() {
		Intent lock_view = new Intent(this, LockActivity.class);
		lock_view.putExtra("setting", false);
		lock_view.putExtra("restart", true);
		startActivity(lock_view);
	}
		
	// 어플이 백그라운드인지 포그라운드인지를 확인
	private boolean isApplicationBroughtToBackground() {
	    ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
	    List<RunningTaskInfo> tasks = am.getRunningTasks(1);
	    if (!tasks.isEmpty()) {
	        ComponentName topActivity = tasks.get(0).topActivity;
	        if (!topActivity.getPackageName().equals(getPackageName())) {
	            return true;
	        }
	    }
	    return false;
	}
}
