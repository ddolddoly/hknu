package com.post_it;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.RemoteViews;
import android.widget.TextView;
import android.widget.TimePicker;

@SuppressLint("SimpleDateFormat")
public class POST_UTIL {
	
	Activity mActivity;
	SharedPreferences preference;
	SharedPreferences preference_memo;
	SharedPreferences.Editor editor;
	
	int curr_year, curr_month, curr_day, curr_hour, curr_minute, save_time;
	int alarm_year, alarm_month, alarm_day, alarm_hour, alarm_minute;
	int color_select_index = 0;
	
	public POST_UTIL(Activity activity) {
		mActivity = activity;
		preference = activity.getSharedPreferences("Setting", Context.MODE_PRIVATE);
		preference_memo = activity.getSharedPreferences("Memo", Context.MODE_PRIVATE);
		save_time = preference.getInt("save_time", 2)+1;
	}
	
	public void Time_Select(final TextView del_time_text){
		
		Calendar c = Calendar.getInstance();
	    int cyear = c.get(Calendar.YEAR);
	    int cmonth = c.get(Calendar.MONTH);
	    int cday = c.get(Calendar.DAY_OF_MONTH);
	    final int hour = c.get(Calendar.HOUR_OF_DAY);
	    final int minute = c.get(Calendar.MINUTE);
	    	    
	    DatePickerDialog.OnDateSetListener mDateSetListener = 
	    new DatePickerDialog.OnDateSetListener() {
	    	public void onDateSet(DatePicker view, final int year, final int monthOfYear, final int dayOfMonth) {
	    		
	    		TimePickerDialog mTimePicker = new TimePickerDialog(mActivity, new TimePickerDialog.OnTimeSetListener() {
	                @Override
	                public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
	                	
	                	curr_year = year;
					    curr_month = monthOfYear+1;
					    curr_day = dayOfMonth;
					    curr_hour = selectedHour;
					    curr_minute = selectedMinute;
					    
					    del_time_text.setText(String.valueOf(year)+"년 "
					    		+String.valueOf(monthOfYear+1)+"월 "
					    		+String.valueOf(dayOfMonth)+"일 "
					    		+String.valueOf(selectedHour)+":"
					    		+String.valueOf(selectedMinute) + "까지");
	          
	                }
	            }, hour, minute, true);
	            mTimePicker.setTitle("삭제시간 선택");
	            mTimePicker.show();
	    	}
	    };
	    DatePickerDialog alert = new DatePickerDialog(mActivity,  mDateSetListener, cyear, cmonth, cday);
	    alert.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
	    alert.setTitle("삭제날짜 선택");
	    alert.show();
	}
	
	public void Alarm_Select(final TextView alarm_time_text){
		Calendar c = Calendar.getInstance();
	    int cyear = c.get(Calendar.YEAR);
	    int cmonth = c.get(Calendar.MONTH);
	    int cday = c.get(Calendar.DAY_OF_MONTH);
	    final int hour = c.get(Calendar.HOUR_OF_DAY);
	    final int minute = c.get(Calendar.MINUTE);
	    	    
	    DatePickerDialog.OnDateSetListener mDateSetListener = 
	    new DatePickerDialog.OnDateSetListener() {
	    	public void onDateSet(DatePicker view, final int year, final int monthOfYear, final int dayOfMonth) {
	    		
	    		TimePickerDialog mTimePicker = new TimePickerDialog(mActivity, new TimePickerDialog.OnTimeSetListener() {
	                @Override
	                public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
	                	
	                	alarm_year = year;
						alarm_month = monthOfYear+1;
						alarm_day = dayOfMonth;
						alarm_hour = selectedHour;
						alarm_minute = selectedMinute;
					    
						alarm_time_text.setText("알람 : "+String.valueOf(year)+"년 "+
								String.valueOf(monthOfYear+1)+"월 "+
								String.valueOf(dayOfMonth)+"일 "+
								String.valueOf(selectedHour)+":"+
								String.valueOf(selectedMinute));
					
	                }
	            }, hour, minute, true);
	            mTimePicker.setTitle("알람시간 선택");
	            mTimePicker.show();
	    	}
	    };
	    DatePickerDialog alert = new DatePickerDialog(mActivity,  mDateSetListener, cyear, cmonth, cday);
	    alert.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
	    alert.setTitle("알람날짜 선택");
	    alert.show();
	}
	
	public void Color_Select(final View view){
		String items[] = {"노랑","파랑","분홍","녹색","빨강"};
		AlertDialog.Builder ab = new AlertDialog.Builder(mActivity);
		ab.setTitle("색상 선택");
		ab.setSingleChoiceItems(items, color_select_index, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				color_select_index = whichButton;
				switch(whichButton) {
				case 0:
					view.setBackgroundColor(Color.parseColor("#FFE400"));
					break;
				case 1:
					view.setBackgroundColor(Color.parseColor("#00D8FF"));
					break;
				case 2:
					view.setBackgroundColor(Color.parseColor("#FFD9FA"));
					break;
				case 3:
					view.setBackgroundColor(Color.parseColor("#CEF279"));
					break;
				case 4:
					view.setBackgroundColor(Color.parseColor("#FFA7A7"));
					break;
				}
			}
		}).setPositiveButton("확인", null);
		ab.show();
	}
		
	
	public String Key_new(TextView del_time_text, TextView alarm_time_text, View view){
		color_select_index = 0;
		view.setBackgroundColor(Color.parseColor("#FFE400"));
		
		SimpleDateFormat dateFormat = new  SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.getDefault());
	    String save_key = dateFormat.format(new Date());
	    
	    Log.i("---","Key_new : 초기화 ("+save_key+")");
	    
	    Calendar c = Calendar.getInstance();
	    c.add(Calendar.DAY_OF_MONTH, preference.getInt("del_time", 2)+1);
	    curr_year = c.get(Calendar.YEAR);
	    curr_month = c.get(Calendar.MONTH)+1;
	    curr_day = c.get(Calendar.DAY_OF_MONTH);
	    curr_hour = c.get(Calendar.HOUR_OF_DAY);
	    curr_minute = c.get(Calendar.MINUTE);
	    
	    del_time_text.setText(String.valueOf(curr_year)+"년 "+
	    		String.valueOf(curr_month)+"월 "+
	    		String.valueOf(curr_day)+"일 "+
	    		String.valueOf(curr_hour)+":"+
	    		String.valueOf(curr_minute) + "까지");
	    
	    alarm_time_text.setText("알람을 지정할 수 있습니다.");
	    alarm_year = 0;
	    alarm_month = 0;
	    alarm_day = 0;
	    alarm_hour = 0;
	    alarm_minute = 0;
	    
	    return save_key;
	}
	
	public void ondel(final String save_key) {
		AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
		builder.setTitle("삭제 하시겠습니까?")
		.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Key_del(save_key);
				mActivity.finish();
			}
		})
		.setNeutralButton("취소", null).show();
	}
	
	public void Key_del(String save_key) {
		Log.i("---","Key_del("+save_key+")");
		Alarm_Del(save_key);
		
		editor = preference_memo.edit();
		String[] list_array = preference_memo.getString("list", "").split(",");
		String key_list = "";
		for(String list_meno : list_array) {
			if (!list_meno.equals(save_key)) {
				key_list = key_list+list_meno+",";
			}
		}
		
		if(key_list.length() == 0) {
			editor.remove("list");
		} else {
			key_list = key_list.substring(0, key_list.length()-1);
			editor.putString("list",key_list);
		}
		
		editor.putString("list",key_list);
		editor.remove(save_key+"_color");
		editor.remove(save_key+"_memo");
		editor.remove(save_key+"_deltime");
		editor.remove(save_key+"_alarmtime");
		editor.commit();
		
		Widget_Update();
	}

	public void Key_save(String save_key, String memo_str, String alarm_str) {
		Log.i("---","Key_save("+save_key+")");
		
		editor = preference_memo.edit();
		if (preference_memo.getString("list", null) == null || preference_memo.getString("list", null).length() == 0) {
			editor.putString("list",save_key);
		} else {
			String[] list_array = preference_memo.getString("list", "").split(",");
			boolean equal_key = false;
			for(String list_meno : list_array) {
				if (list_meno.equals(save_key)) {
					equal_key = true;
					break;
				}
			}
			
			if (!equal_key) {
				editor.putString("list",preference_memo.getString("list", "")+","+save_key);
			}
		}
		editor.putInt(save_key+"_color",color_select_index);
		editor.putString(save_key+"_memo",memo_str);
		if (curr_year != 0 || curr_day != 0) {
			editor.putString(save_key+"_deltime",String.valueOf(curr_year)+"년 "+String.valueOf(curr_month)+"월 "+String.valueOf(curr_day)+"일 "+String.valueOf(curr_hour)+":"+String.valueOf(curr_minute));
		}		
		editor.putString(save_key+"_alarmtime", alarm_str);
		editor.commit();
		
		Widget_Update();
		Alarm_Set(save_key);
	}
	
	public void Widget_Update(){
		ComponentName componentname = new ComponentName(mActivity, PostIt_Widget.class);
        AppWidgetManager appwidgetmanager = AppWidgetManager.getInstance(mActivity);
        RemoteViews remoteViews = new RemoteViews(mActivity.getPackageName(), R.layout.widget_postit);
        String[] list_str = preference_memo.getString("list", "").split(",");
        boolean memo_bool = false;
		for (String key_str : list_str) {
			if(preference_memo.getInt(key_str+"_color", 0) == 0 && key_str.length() != 0) {
				remoteViews.setTextViewText(R.id.memo_text, preference_memo.getString(key_str + "_memo", ""));
				memo_bool = true;
				break;
			}
		}
		
		if (!memo_bool) {
			remoteViews.setTextViewText(R.id.memo_text, "메모를 추가 하세요.");
		}
        appwidgetmanager.updateAppWidget(componentname, remoteViews);
	}
	
	
	public void Alarm_Set(String save_key) {
		Log.i("---","Alarm_Set("+save_key+")");
		AlarmManager alarmManager = (AlarmManager) mActivity.getSystemService(Context.ALARM_SERVICE);
		if (curr_year != 0 && curr_day != 0) {
			Intent alarm_intent = new Intent("com.post_it.ALARM");
	        alarm_intent.putExtra("alarm", false);
	        alarm_intent.putExtra("key", save_key);
	        try {
	        	PendingIntent pIntent = PendingIntent.getActivity(mActivity, diffOfDate_alarm(save_key), alarm_intent, 0);
	        	alarmManager.set(AlarmManager.RTC, System.currentTimeMillis() + diffOfDate(String.valueOf(curr_year)+"/"+String.valueOf(curr_month)+"/"+String.valueOf(curr_day)+"/"+String.valueOf(curr_hour)+"/"+String.valueOf(curr_minute)), pIntent);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        
        if (alarm_year != 0 && alarm_day != 0) {
        	Intent alarm_intent_a = new Intent("com.post_it.ALARM");
        	alarm_intent_a.putExtra("alarm", true);
        	alarm_intent_a.putExtra("key", save_key);
            try {
            	PendingIntent pIntent_a = PendingIntent.getActivity(mActivity, diffOfDate_alarm_2(save_key), alarm_intent_a, 0);
            	alarmManager.set(AlarmManager.RTC, System.currentTimeMillis() + diffOfDate(String.valueOf(alarm_year)+"/"+String.valueOf(alarm_month)+"/"+String.valueOf(alarm_day)+"/"+String.valueOf(alarm_hour)+"/"+String.valueOf(alarm_minute)), pIntent_a);
    		} catch (Exception e) {
    			e.printStackTrace();
    		}
        }
	}
	
	public void Alarm_Del(String save_key) {
		Log.i("---","Alarm_Del("+save_key+")");
		AlarmManager alarmManager = (AlarmManager) mActivity.getSystemService(Context.ALARM_SERVICE); 
		try {
			Intent alarm_intent = new Intent("com.post_it.ALARM");
			PendingIntent pIntent = PendingIntent.getActivity(mActivity, diffOfDate_alarm(save_key), alarm_intent, 0);
			alarmManager.cancel(pIntent);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			Intent alarm_intent_a = new Intent("com.post_it.ALARM");
			PendingIntent pIntent_a = PendingIntent.getActivity(mActivity, diffOfDate_alarm_2(save_key), alarm_intent_a, 0);
			alarmManager.cancel(pIntent_a);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static long diffOfDate(String end) throws Exception {
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd/HH/mm");
	    Date begin = new Date();
	    Date endDate = formatter.parse(end);
	    long diff = endDate.getTime() - begin.getTime();
	    return diff;
	}
	
	public static int diffOfDate_alarm(String end) throws Exception {
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
	    Date begin = formatter.parse("20150901010100");
	    Date endDate = formatter.parse(end);
	    long diff = endDate.getTime() - begin.getTime();
	    Log.i("----","alram1_key = "+String.valueOf(diff/1000));
	    return (int) diff/1000;
	}
	
	public static int diffOfDate_alarm_2(String end) throws Exception {
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
	    Date begin = formatter.parse("20150801010100");
	    Date endDate = formatter.parse(end);
	    long diff = endDate.getTime() - begin.getTime();
	    Log.i("----","alram2_key = "+String.valueOf(diff/1000));
	    return (int) diff/1000;
	}

	
	public int Save_Verify() throws ParseException {
		SimpleDateFormat dateFormat = new  SimpleDateFormat("yyyy/MM/dd/HH/mm", java.util.Locale.getDefault());
		String del_str = String.valueOf(curr_year)+"/"+String.valueOf(curr_month)+"/"+String.valueOf(curr_day)+"/"+String.valueOf(curr_hour)+"/"+String.valueOf(curr_minute);
		String alarm_str = String.valueOf(alarm_year)+"/"+String.valueOf(alarm_month)+"/"+String.valueOf(alarm_day)+"/"+String.valueOf(alarm_hour)+"/"+String.valueOf(alarm_minute);

		Date now_date = new Date();
		Date del_str_date = dateFormat.parse(del_str);
		
		if (now_date.after(del_str_date)) {
			return 1;
		}
		
		if (alarm_year != 0 && alarm_day != 0) {
			if (now_date.after(dateFormat.parse(alarm_str))) {
				return 2;
			}
			
			if (dateFormat.parse(alarm_str).after(del_str_date)) {
				return 3;
			}
		}
		return 0;
	}
	
	
	public int getSave_time() {
		return save_time;
	}

	public void setSave_time(int save_time) {
		this.save_time = save_time;
	}
}
