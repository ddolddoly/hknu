package com.post_it;

import java.util.Timer;
import java.util.TimerTask;

import com.post_it.lock.LockPatternUtils;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class LoadingActivity extends Activity {

	private Timer intro_timer;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_loading);
		
		// 로딩 화면 표시 후 타이머 스케쥴링을 걸어서 2초후 IntroTimerTask() 호출 
		intro_timer = new Timer(false);
		intro_timer.schedule(new IntroTimerTask(), 2000);
	}
	
	public class IntroTimerTask extends TimerTask {
		@Override
		public void run() {
			// 페튼이 저장되어있는지 없는지를 확인하여 없을경우(Null) 설정하는 패턴페이지로, 있을경우 확인하는 패턴페이지로 가도록 저정
			String savedData = LockPatternUtils.loadFromPreferences(LoadingActivity.this);
			if (savedData == null) {
				Intent lock_set_view = new Intent(LoadingActivity.this, LockSetActivity.class);
				lock_set_view.putExtra("setting", false);
				startActivity(lock_set_view);
			} else {
				Intent lock_view = new Intent(LoadingActivity.this, LockActivity.class);
				lock_view.putExtra("setting", false);
				lock_view.putExtra("restart", false);
				startActivity(lock_view);
			}
		}
	}
	
	// Activity 가 종료 되거나 화면상에서 사라질때 호출
	@Override
	protected void onStop() {
		super.onStop();
		finish();
	}
	
	// Back 버튼 이벤트
	@Override
	public void onBackPressed() {
		intro_timer.cancel();
		finish();
	}
}
