package com.post_it;

import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener {
	
	static Activity mActivity;
	Button post_edit, save_post, setting;
	boolean Background_App = false;
	
	String type_str;
	Handler handler = new Handler();
	
	// 화면이 표출되면 호출되는 onResume 
	@Override
	public void onResume() {
	    super.onResume();
	    if (Background_App) {
	    	Lock();
	    }
	}

	// 화면이 사라지면 호출되는 onPause
	@Override
	public void onPause() {
	    super.onPause();
	    Background_App = isApplicationBroughtToBackground();
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_main);
	    		
	    mActivity = this;
	    
	    post_edit = (Button) this.findViewById(R.id.post_edit);
	    save_post = (Button) this.findViewById(R.id.save_post);
	    setting = (Button) this.findViewById(R.id.setting);
	    
	    post_edit.setOnClickListener(this);
	    save_post.setOnClickListener(this);
	    setting.setOnClickListener(this);
	    
	    type_str = this.getIntent().getStringExtra("TYPE");
	    if (type_str == null) return;
	    if (type_str.equals("ADD")) {
	    	Lock();
	    	PostIt_Edit();
	    } else if (type_str.equals("Modify")) {
	    	Save_PostIt();
	    	handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					Intent modify_post = new Intent(MainActivity.this, ModifyPostItEditActivity.class);
			    	modify_post.putExtra("alarm", true);
			    	modify_post.putExtra("key", MainActivity.this.getIntent().getStringExtra("key"));
					startActivity(modify_post);
				}
			}, 150);
	    	handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					Lock();
				}
	    	}, 300);
	    }
	}

	// 화면상에서의 버튼 클릭 이벤트리스너
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.post_edit:
			PostIt_Edit();
			break;
		case R.id.save_post:
			Save_PostIt();
			break;
		case R.id.setting:
			Setting();
			break;
		}
	}

	// 포스트잇 작성
	public void PostIt_Edit(){
		Intent post_edit = new Intent(this, PostItEditActivity.class);
		startActivity(post_edit);
	}
	
	// 보관함 포스트잇
	public void Save_PostIt(){
		Intent save_post = new Intent(this, SavePostActivity.class);
		startActivity(save_post);
	}
	
	// 설정화면
	public void Setting() {
		Intent setting = new Intent(this, SettingActivity.class);
		startActivity(setting);
	}
	
	// 잠금화면
	public void Lock() {
		Intent lock_view = new Intent(MainActivity.this, LockActivity.class);
		lock_view.putExtra("setting", false);
		lock_view.putExtra("restart", true);
		startActivity(lock_view);
	}
	
	// 어플이 백그라운드인지 포그라운드인지를 확인
	private boolean isApplicationBroughtToBackground() {
	    ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
	    List<RunningTaskInfo> tasks = am.getRunningTasks(1);
	    if (!tasks.isEmpty()) {
	        ComponentName topActivity = tasks.get(0).topActivity;
	        if (!topActivity.getPackageName().equals(getPackageName())) {
	            return true;
	        }
	    }
	    return false;
	}
}
