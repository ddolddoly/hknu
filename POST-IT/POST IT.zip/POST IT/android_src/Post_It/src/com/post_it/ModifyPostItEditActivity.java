package com.post_it;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("SimpleDateFormat")
public class ModifyPostItEditActivity extends Activity implements OnClickListener {

	static Activity mActivity;
	boolean Background_App = false;
	
	String key_str;
	boolean alarm_start;
	SharedPreferences preference_memo;
		
	POST_UTIL post_util;
	
	EditText edit_text;
	Button color_btn, time_btn, home_btn, save_btn, cancel_btn, alarm_btn;
	ScrollView scrollView1;
	TextView time_text, time_alarm_text;
	
	// 화면이 표출되면 호출되는 onResume 
	@Override
	public void onResume() {
		super.onResume();
		if (Background_App) {
			Lock();
		}
	}

	// 화면이 사라지면 호출되는 onPause
	@Override
	public void onPause() {
	    super.onPause();
	    Background_App = isApplicationBroughtToBackground();
	}
	
	// 액티비티가 완전종료시에... 락해지를 못하고 꺼버리면 연장을 못하고 삭제된다.
	@Override
	public void onDestroy() {
		super.onDestroy();
		if(alarm_start) {
			post_util.Key_del(key_str);
		}
	}
		
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_postedit);
	    
	    mActivity = this;	 
	    post_util = new POST_UTIL(this);
	    
	    alarm_start = this.getIntent().getBooleanExtra("alarm", false);
	    key_str = this.getIntent().getStringExtra("key");
	    preference_memo = this.getSharedPreferences("Memo", Context.MODE_PRIVATE);
   	 
	    color_btn = (Button) this.findViewById(R.id.color_btn);
	    time_btn = (Button) this.findViewById(R.id.time_btn);
	    home_btn = (Button) this.findViewById(R.id.home_btn);
	    save_btn = (Button) this.findViewById(R.id.save_btn);
	    cancel_btn = (Button) this.findViewById(R.id.cancel_btn);
	    alarm_btn = (Button) this.findViewById(R.id.alarm_btn);
	    
	    if(alarm_start) {
	    	home_btn.setVisibility(View.GONE);
	    }
	    
	    scrollView1 = (ScrollView) this.findViewById(R.id.scrollView1);
	    time_text = (TextView) this.findViewById(R.id.time_text);
	    time_alarm_text = (TextView) this.findViewById(R.id.time_alarm_text);
	    		
	    color_btn.setOnClickListener(this);
	    time_btn.setOnClickListener(this);
	    home_btn.setOnClickListener(this);
	    save_btn.setOnClickListener(this);
	    cancel_btn.setOnClickListener(this);
	    alarm_btn.setOnClickListener(this);
	    
	    edit_text = (EditText) this.findViewById(R.id.editText1);
	    
	    edit_text.setText(preference_memo.getString(key_str+"_memo", ""));
	    time_text.setText(preference_memo.getString(key_str+"_deltime", "")+ "까지");
	    time_alarm_text.setText(preference_memo.getString(key_str+"_alarmtime", ""));
	    post_util.color_select_index = preference_memo.getInt(key_str+"_color", 0);
	    
		switch(post_util.color_select_index) {
		case 0:
			scrollView1.setBackgroundColor(Color.parseColor("#FFE400"));
			break;
		case 1:
			scrollView1.setBackgroundColor(Color.parseColor("#00D8FF"));
			break;
		case 2:
			scrollView1.setBackgroundColor(Color.parseColor("#FFD9FA"));
			break;
		case 3:
			scrollView1.setBackgroundColor(Color.parseColor("#CEF279"));
			break;
		case 4:
			scrollView1.setBackgroundColor(Color.parseColor("#FFA7A7"));
			break;
		}
	}

	@Override
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.color_btn:
			post_util.Color_Select(scrollView1);
			break;
		case R.id.time_btn:
			post_util.Time_Select(time_text);
			break;
		case R.id.save_btn:
			Save();
			break;
		case R.id.home_btn:
			finish();
			break;
		case R.id.cancel_btn:
			post_util.ondel(key_str);
			break;
		case R.id.alarm_btn: // 알람 설정버튼
			post_util.Alarm_Select(time_alarm_text);
			break;
		}
	}
	
	public void Save(){
		try {
			int result = Save_Verify(); // 유효성에 맞는지를 확인하여 코드를 가져온다. 0일때만 정상
			if (result == 0) { // 정상일경우
				post_util.Key_save(key_str, edit_text.getText().toString(), time_alarm_text.getText().toString());
				Toast.makeText(getApplicationContext(), "수정되었습니다.", Toast.LENGTH_SHORT).show();
				finish();
			} else { // 저장에 유효하지 않으면 알람을 띠운다. 자동저장일경우 토스트를 띠워서 사용한다.
				String alert_str = "삭제 시간이 현제 시간보다 전입니다.";
				if (result == 2) {
					alert_str = "알람 시간이 현제 시간보다 전입니다.";
				} else if (result == 3) {
					alert_str = "삭제 시간이 알람 시간보다 전입니다.";
				}
				AlertDialog.Builder builder = new AlertDialog.Builder(ModifyPostItEditActivity.this);
				builder.setTitle(alert_str)
				.setPositiveButton("확인", null).show();
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	
	public int Save_Verify() throws ParseException {
		SimpleDateFormat dateFormat = new  SimpleDateFormat("yyyy년 MM월 dd일 HH:mm까지", java.util.Locale.getDefault());
		SimpleDateFormat dateFormat_alarm = new  SimpleDateFormat("알람 : yyyy년 MM월 dd일 HH:mm", java.util.Locale.getDefault());
		
		Date now_date = new Date();
		Date del_str_date = dateFormat.parse(time_text.getText().toString());
		
		if (now_date.after(del_str_date)) {
			return 1;
		}
		
		if (!time_alarm_text.getText().toString().equals("알람을 지정할 수 있습니다.")) {
			
			if (now_date.after(dateFormat_alarm.parse(time_alarm_text.getText().toString()))) {
				return 2;
			}
			
			if (dateFormat.parse(time_alarm_text.getText().toString()).after(del_str_date)) {
				return 3;
			}
		}
		return 0;
	}
	
	// 잠금화면
	public void Lock() {
		Intent lock_view = new Intent(this, LockActivity.class);
		lock_view.putExtra("setting", false);
		lock_view.putExtra("restart", true);
		startActivity(lock_view);
	}
		
	// 어플이 백그라운드인지 포그라운드인지를 확인
	private boolean isApplicationBroughtToBackground() {
	    ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
	    List<RunningTaskInfo> tasks = am.getRunningTasks(1);
	    if (!tasks.isEmpty()) {
	        ComponentName topActivity = tasks.get(0).topActivity;
	        if (!topActivity.getPackageName().equals(getPackageName())) {
	            return true;
	        }
	    }
	    return false;
	}
}
