package com.post_it;

import java.util.ArrayList;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class PostIt_Widget extends AppWidgetProvider {
		
	SharedPreferences preference_memo;
	SharedPreferences.Editor editor;
	
	String[] list_str;
	
	ArrayList<String> memo_array;
	int select_memo_index = 0;
	
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {		
		preference_memo = context.getSharedPreferences("Memo", Context.MODE_PRIVATE);
		RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_postit);
		
		if (preference_memo.getString("list", null) == null) {
			remoteViews.setTextViewText(R.id.memo_text, "메모를 추가 하세요.");
		} else {
			list_str = preference_memo.getString("list", "").split(",");
			boolean memo_bool = false;
			for (String key_str : list_str) {
				if(preference_memo.getInt(key_str+"_color", 0) == 0 && key_str.length() != 0) {
					remoteViews.setTextViewText(R.id.memo_text, preference_memo.getString(key_str + "_memo", ""));
					memo_bool = true;
					break;
				}
			}
			
			if (!memo_bool) {
				remoteViews.setTextViewText(R.id.memo_text, "메모를 추가 하세요.");
			}
		}		
		
		Intent intent = new Intent();
		intent.setAction("com.post_it.ADD_WIDGET");
		remoteViews.setOnClickPendingIntent(R.id.add_btn, PendingIntent.getBroadcast(context, 0, intent,
				PendingIntent.FLAG_UPDATE_CURRENT));
		
		intent = new Intent();
		intent.setAction("com.post_it.NEXT_WIDGET");
		remoteViews.setOnClickPendingIntent(R.id.next_btn, PendingIntent.getBroadcast(context, 0, intent,
				PendingIntent.FLAG_UPDATE_CURRENT));
		
		intent = new Intent();
		intent.setAction("com.post_it.PREV_WIDGET");
		remoteViews.setOnClickPendingIntent(R.id.prev_btn, PendingIntent.getBroadcast(context, 0, intent,
				PendingIntent.FLAG_UPDATE_CURRENT));
		
		pushWidgetUpdate(context, remoteViews);
	}
	
	@Override
    public void onReceive(Context context, Intent intent) { 
        super.onReceive(context, intent);
        
        String action = intent.getAction();
        
        if (action.equals("com.post_it.ADD_WIDGET")) {
        	Intent intent_noti = new Intent();
    		intent_noti.setClassName("com.post_it", "com.post_it.MainActivity");
    		intent_noti.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
    		intent_noti.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    		intent_noti.putExtra("TYPE", "ADD");
    		context.startActivity(intent_noti);
        } else if (action.equals("com.post_it.NEXT_WIDGET")) {
        	memo_count(context);
        	if (memo_array.size() == 0) {
        		RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_postit);
        		remoteViews.setTextViewText(R.id.memo_text, "메모를 추가 하세요.");
            	pushWidgetUpdate(context, remoteViews);
        	} else {
        		select_memo_index++;
        		
        		if(memo_array.size() <= select_memo_index) {
            		select_memo_index = 0;
            	}
            	
        		editor = preference_memo.edit();
        		editor.putInt("select_count", select_memo_index);
        		editor.commit();
        		
            	RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_postit);
            	remoteViews.setTextViewText(R.id.memo_text, memo_array.get(select_memo_index));
            	pushWidgetUpdate(context, remoteViews);
        	}
        } else if (action.equals("com.post_it.PREV_WIDGET")) {
        	memo_count(context);
        	if (memo_array.size() == 0) {
        		RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_postit);
        		remoteViews.setTextViewText(R.id.memo_text, "메모를 추가 하세요.");
            	pushWidgetUpdate(context, remoteViews);
        	} else {
        		select_memo_index--;
        		
        		if(0 > select_memo_index) {
            		select_memo_index = memo_array.size()-1;
            	}
            	        		
        		editor = preference_memo.edit();
        		editor.putInt("select_count", select_memo_index);
        		editor.commit();
        		
            	RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_postit);
            	remoteViews.setTextViewText(R.id.memo_text, memo_array.get(select_memo_index));
            	pushWidgetUpdate(context, remoteViews);
        	}
        }
	}
	
	public static void pushWidgetUpdate(Context context, RemoteViews remoteViews) {
		ComponentName myWidget = new ComponentName(context,
				PostIt_Widget.class);
		AppWidgetManager manager = AppWidgetManager.getInstance(context);
		manager.updateAppWidget(myWidget, remoteViews);
	}
	
	public void memo_count(Context context) {
		memo_array = new ArrayList<String>();
		preference_memo = context.getSharedPreferences("Memo", Context.MODE_PRIVATE);
		if (preference_memo.getString("list", null) != null) {
			list_str = preference_memo.getString("list", "").split(",");
	    	for (String key_str : list_str) {
				if(preference_memo.getInt(key_str+"_color", 0) == 0) {
					memo_array.add(preference_memo.getString(key_str + "_memo", ""));
				}
	    	}
		}
		
		select_memo_index = preference_memo.getInt("select_count", 0);
	}
}
