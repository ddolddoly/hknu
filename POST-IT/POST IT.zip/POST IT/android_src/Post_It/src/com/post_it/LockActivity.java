package com.post_it;

import java.util.List;

import com.post_it.lock.LockPatternUtils;
import com.post_it.lock.LockPatternView;
import com.post_it.lock.LockPatternView.Cell;
import com.post_it.lock.LockPatternView.OnPatternListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class LockActivity extends Activity implements OnPatternListener {
		
	boolean restart_bool;
	boolean setting_bool;
	
	TextView title_text;
	LockPatternView lock_pattern_view;
	
	String savedData;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_lock);
	    
	    // 백그라운드에서 포그라운드로 올라올때의 잠금화면표기 기준
	    restart_bool = this.getIntent().getBooleanExtra("restart", false);
	    // 설정에서 불러왔을대의 기준
	    setting_bool = this.getIntent().getBooleanExtra("setting", false);
	    
	    // 저장된 패튼 가져오기
	    savedData = LockPatternUtils.loadFromPreferences(this);
	    
	    title_text = (TextView) this.findViewById(R.id.title_text);
	    lock_pattern_view = (LockPatternView) this.findViewById(R.id.lock_pattern_view);
	    lock_pattern_view.setOnPatternListener(this);
	}

	@Override
	public void onPatternStart() {}

	@Override
	public void onPatternCleared() {}

	@Override
	public void onPatternCellAdded(List<Cell> pattern) {}

	@Override
	public void onPatternDetected(List<Cell> pattern) {
		String data = LockPatternUtils.convertToSequence(pattern);
		
		// 저장된 패턴이 같은지를 확인 
		if (data != null && data.equals(savedData)) {
			
			if (!restart_bool) {
				Intent main_view = new Intent(this, MainActivity.class);
				startActivity(main_view);
			}
			
			if (setting_bool) {
				Intent lock_set_view = new Intent(this, LockSetActivity.class);
				lock_set_view.putExtra("setting", true);
				startActivity(lock_set_view);
			}
			
			finish();
			
		} else {
			title_text.setText("패턴이 틀렸습니다. 다시 입력하세요.");
		}
		
		lock_pattern_view.clearPattern();
	}
	
	// 백버튼을 이용하여 탈출하려 할때 하단에 깔리 모든 Activity를 종료
	@Override
	public void onBackPressed() {
		if (!setting_bool) {
			if ((MainActivity) MainActivity.mActivity != null) {
				((MainActivity) MainActivity.mActivity).finish();
			}
			
			if ((PostItEditActivity) PostItEditActivity.mActivity != null) {
				((PostItEditActivity) PostItEditActivity.mActivity).finish();
			}
			
			if ((SavePostActivity) SavePostActivity.mActivity != null) {
				((SavePostActivity) SavePostActivity.mActivity).finish();
			}
			
			if ((ModifyPostItEditActivity) ModifyPostItEditActivity.mActivity != null) {
				((ModifyPostItEditActivity) ModifyPostItEditActivity.mActivity).finish();
			}

			if ((SettingActivity) SettingActivity.mActivity != null) {
				((SettingActivity) SettingActivity.mActivity).finish();
			}
		}
		
		finish();
	}
}
