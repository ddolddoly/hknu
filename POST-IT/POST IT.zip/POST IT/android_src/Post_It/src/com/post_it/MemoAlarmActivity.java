package com.post_it;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.Window;
import android.view.WindowManager;

public class MemoAlarmActivity extends Activity {
	
	SharedPreferences preference_memo;
	SharedPreferences.Editor editor;
	
	POST_UTIL post_util;
	
	String save_key;
	boolean alarm_del;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    requestWindowFeature(Window.FEATURE_NO_TITLE);
	    
	    post_util = new POST_UTIL(this);
	    
	    alarm_del = this.getIntent().getBooleanExtra("alarm", false);
	    save_key = this.getIntent().getStringExtra("key");
	    preference_memo = this.getSharedPreferences("Memo", Context.MODE_PRIVATE);
	    
	    
	    // 화면 깨우기
	    final Window win = this.getWindow();
		win.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
				| WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);

		if (!getIntent().getBooleanExtra("screen_off", false)) {
			win.addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
		}
		
		// 소리 설정 알람소리 및 진동
		AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
		final int mode = am.getRingerMode();
		final Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		
		Handler handler = new Handler();
	    handler.post(new Runnable() {
	    	public void run() {
	    		if (mode == 2) {
	    			Uri ringtoneUri = RingtoneManager.getActualDefaultRingtoneUri(
	    					getApplicationContext(), RingtoneManager.TYPE_NOTIFICATION);
	    			Ringtone ringtone = RingtoneManager.getRingtone(
	    					getApplicationContext(), ringtoneUri);
	    			ringtone.play();
	    		}
	    		vibe.vibrate(500);
	    	}
	    });
	    
	    // 알람일 경우와 삭제알람일경우 판단하여 AlertDialog를 띠운다.
	    if (alarm_del) {
	    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
	 		builder.setIcon(R.drawable.ic_launcher);
	     	builder.setTitle("메모 알람");
	 		builder.setMessage(preference_memo.getString(save_key+"_memo",""));
	 		builder.setCancelable(false);
	 		builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
	 			@Override
	 			public void onClick(DialogInterface dialog, int which) {
	 				finish();
	 			}
	 		});
	 		
	 		AlertDialog alertDialog;
	 		alertDialog = builder.create();
	 		alertDialog.show();
	    } else {
	    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
	 		builder.setIcon(R.drawable.ic_launcher);
	     	builder.setTitle("메모 삭제");
	 		builder.setMessage(preference_memo.getString(save_key+"_memo",""));
	 		builder.setCancelable(false);
	 		builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
	 			@Override
	 			public void onClick(DialogInterface dialog, int which) {
	 				post_util.Key_del(save_key);
	 				finish();
	 			}
	 		});
	 		builder.setNegativeButton("연장하기", new DialogInterface.OnClickListener() {
	 			@Override
	 			public void onClick(DialogInterface dialog, int which) {
	 				Intent intent_noti = new Intent();
	 	    		intent_noti.setClassName("com.post_it", "com.post_it.MainActivity");
	 	    		intent_noti.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	 	    		intent_noti.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	 	    		intent_noti.putExtra("TYPE", "Modify");
	 	    		intent_noti.putExtra("key", save_key);
	 	    		startActivity(intent_noti);
	 				finish();
	 			}
	 		});
	 		
	 		AlertDialog alertDialog;
	 		alertDialog = builder.create();
	 		alertDialog.show();
	    }
	}
}
