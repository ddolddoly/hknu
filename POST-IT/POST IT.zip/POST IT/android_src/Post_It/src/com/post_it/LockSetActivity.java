package com.post_it;

import java.util.List;

import com.post_it.lock.LockPatternUtils;
import com.post_it.lock.LockPatternView;
import com.post_it.lock.LockPatternView.Cell;
import com.post_it.lock.LockPatternView.OnPatternListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class LockSetActivity extends Activity implements OnPatternListener {

	boolean setting_bool;
	
	TextView title_text;
	LockPatternView lock_pattern_view;
	
	boolean FIRST_SECOND;
	String first_pattern;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_lock);
	    
	    // 설정창에서 온것인지 아닌지를 확인
	    setting_bool = this.getIntent().getBooleanExtra("setting", false);
	    
	    title_text = (TextView) this.findViewById(R.id.title_text);
	    lock_pattern_view = (LockPatternView) this.findViewById(R.id.lock_pattern_view);
	    lock_pattern_view.setOnPatternListener(this);
		
	    // 기본 초기화 - 패턴, 1번째 패턴인지 2번째 패턴인지
	    first_pattern = null;
		FIRST_SECOND = false;
		title_text.setText("초기 설정할 패턴을 입력하세요.");
	}

	@Override
	public void onPatternStart() {}

	@Override
	public void onPatternCleared() {}

	@Override
	public void onPatternCellAdded(List<Cell> pattern) {}

	@Override
	public void onPatternDetected(List<Cell> pattern) {
		//패턴 확인
		if (!FIRST_SECOND) {
			first_pattern = LockPatternUtils.convertToSequence(pattern);
			FIRST_SECOND = true;
			title_text.setText("다시 한번 패턴을 입력하세요.");
		} else {
			String data = LockPatternUtils.convertToSequence(pattern);
		
			if (data != null && data.equals(first_pattern)) {
				LockPatternUtils.saveToPreferences(this, data);
				Toast.makeText(getApplicationContext(), "패턴이 설정되었습니다.", Toast.LENGTH_LONG).show();
				closeActivity();
			} else {
				first_pattern = null;
				FIRST_SECOND = false;
				title_text.setText("초기 설정할 패턴을 입력하세요.");
				Toast.makeText(getApplicationContext(), "패턴이 맞지 않습니다. 다시 시도하세요.", Toast.LENGTH_LONG).show();
			}
		}
		lock_pattern_view.clearPattern();
	}
	
	
	public void closeActivity(){
		
		if (!setting_bool) {
			Intent main_view = new Intent(this, MainActivity.class);
			startActivity(main_view);
		}
		
		finish();
	}
}
