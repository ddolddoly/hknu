package com.post_it;

import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

public class SettingActivity extends Activity implements OnClickListener, OnSeekBarChangeListener {
	
	static Activity mActivity;
	boolean Background_App = false;
	
	SeekBar seek_bar, seek_bar_1;
	TextView save_time_text, del_time_text;
	Button lock_modify;
	
	SharedPreferences preference;
	SharedPreferences.Editor editor;

	// 화면이 표출되면 호출되는 onResume 
	@Override
	public void onResume() {
		super.onResume();
		if (Background_App) {
			Lock();
		}
	}

	// 화면이 사라지면 호출되는 onPause
	@Override
	public void onPause() {
	    super.onPause();
	    Background_App = isApplicationBroughtToBackground();
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_setting);
	    
	    mActivity = this;
	    
	    preference = this.getSharedPreferences("Setting", Context.MODE_PRIVATE);
	    
	    seek_bar = (SeekBar) this.findViewById(R.id.seek_bar);
	    save_time_text = (TextView) this.findViewById(R.id.save_time_text);
	    seek_bar_1 = (SeekBar) this.findViewById(R.id.seek_bar_1);
	    del_time_text = (TextView) this.findViewById(R.id.del_time_text);
	    lock_modify = (Button) this.findViewById(R.id.lock_modify);
	    
	    seek_bar.setProgress(preference.getInt("save_time", 2));
	    save_time_text.setText(preference.getInt("save_time", 2)+1+"분");
	    
	    seek_bar_1.setProgress(preference.getInt("del_time", 2));
	    del_time_text.setText(preference.getInt("del_time", 2)+1+"일");
	    
	    seek_bar.setOnSeekBarChangeListener(this);
	    seek_bar_1.setOnSeekBarChangeListener(this);
	    lock_modify.setOnClickListener(this);
	}

	// 변경하기 버튼 클릭시에 lockSetting을 하는 페이지로 이동한다.
	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.lock_modify) {
			Intent lock_view = new Intent(this, LockActivity.class);
			lock_view.putExtra("setting", true);
			lock_view.putExtra("restart", true);
			startActivity(lock_view);
		}
	}

	// SeekBar의 값이 변경되면 표시되면 분, 일의 값이 변경된다.
	@Override
	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		if(seekBar.getId() == R.id.seek_bar) {
			save_time_text.setText(String.valueOf(progress+1)+"분");
		} else {
			del_time_text.setText(String.valueOf(progress+1)+"일");
		}
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {
		
	}
	
	// SeekBar에 움직임이 멈추었을 경우 세팅을 저장한다.
	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
		editor = preference.edit();
		editor.putInt("save_time", seek_bar.getProgress());
		editor.putInt("del_time", seek_bar_1.getProgress());
		editor.commit();
	}
	
	
	// 잠금화면
	public void Lock() {
		Intent lock_view = new Intent(this, LockActivity.class);
		lock_view.putExtra("setting", false);
		lock_view.putExtra("restart", true);
		startActivity(lock_view);
	}
		
	// 어플이 백그라운드인지 포그라운드인지를 확인
	private boolean isApplicationBroughtToBackground() {
	    ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
	    List<RunningTaskInfo> tasks = am.getRunningTasks(1);
	    if (!tasks.isEmpty()) {
	        ComponentName topActivity = tasks.get(0).topActivity;
	        if (!topActivity.getPackageName().equals(getPackageName())) {
	            return true;
	        }
	    }
	    return false;
	}
}
