package com.example.clientapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.clientapp.Bluetooth.BlueActivity;
import com.example.clientapp.QR.QrActivity;

public class MainActivity extends Activity {
    private Button blueBtn, qrBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        blueBtn = (Button) findViewById(R.id.blueBtn);
        qrBtn = (Button) findViewById(R.id.qrBtn);
        blueBtn.setOnClickListener(transfer);
        qrBtn.setOnClickListener(transfer);
    }

    View.OnClickListener transfer = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v.getId()==R.id.blueBtn){
                Intent intent = new Intent(MainActivity.this, BlueActivity.class);
                startActivity(intent);
            }else if(v.getId()==R.id.qrBtn){
                Intent intent = new Intent(MainActivity.this, QrActivity.class);
                startActivity(intent);
            }
        }
    };
}
