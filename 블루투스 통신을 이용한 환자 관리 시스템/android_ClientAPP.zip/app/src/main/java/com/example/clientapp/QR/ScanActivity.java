package com.example.clientapp.QR;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.clientapp.MainActivity;
import com.example.clientapp.R;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class ScanActivity extends Activity {
    private TextView scanName, scanAddr, scanNum;
    private String num = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);
        scanName = (TextView) findViewById(R.id.scanName);
        scanAddr = (TextView) findViewById(R.id.scanAddr);
        scanNum = (TextView) findViewById(R.id.scanNum);

        new IntentIntegrator(this).initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // 카메라에서 스캔이 정상적으로 이루어질 경우 결과코드가 -1로 진행
        if (resultCode == -1) {
            IntentResult result = IntentIntegrator.parseActivityResult(requestCode,
                    resultCode, data);
            // qr코드에 저장된 내용중 !!을 기준으로 잘라서 info배열에 저장
            String[] info = result.getContents().split("!!");
            scanName.setText(info[0]);
            scanAddr.setText(info[1]);
            scanNum.setText(info[2]);
            num = info[2];
            Toast.makeText(getApplicationContext(), "5초 후, 자동으로 통화가 시작됩니다", Toast.LENGTH_SHORT).show();
            // 화면에 정보를 뿌려준 뒤 5초후 전화를 검
            Handler handler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + num));
                    startActivity(intent);
                }
            };
            handler.sendEmptyMessageDelayed(0, 5000);
        }else{
            finish();
        }
    }
}
