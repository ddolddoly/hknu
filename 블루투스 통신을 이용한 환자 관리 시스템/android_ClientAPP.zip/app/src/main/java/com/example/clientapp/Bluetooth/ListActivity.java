package com.example.clientapp.Bluetooth;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import com.example.clientapp.R;

/**
 * Created by IVE on 2015-06-10.
 * 블루투스 통신 액티비티
 * 서버, 클라이언트 소켓 쓰레드를 동시에 돌려 연결한 대상을 검색하면서 다른 호스트의 연결 또한 기다린다
 * 해당되는 연결이 발생하면 다른 쓰레드를 죽이고 연결이 이루어진다
 */
public class ListActivity extends Activity {
    private TextView listText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listText = (TextView) findViewById(R.id.listText);
        listText.setMovementMethod(new ScrollingMovementMethod());
        listText.setText(getPreferences());

    }
    // 값 불러오기
    private String getPreferences(){
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        return pref.getString("Log", "");
    }
}