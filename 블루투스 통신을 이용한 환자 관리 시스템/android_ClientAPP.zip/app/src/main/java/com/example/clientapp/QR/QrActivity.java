package com.example.clientapp.QR;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.clientapp.Bluetooth.PushActivity;
import com.example.clientapp.R;

public class QrActivity extends Activity {
    private Button scanBtn, makeBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);
        scanBtn = (Button) findViewById(R.id.scanBtn);
        makeBtn = (Button) findViewById(R.id.makeBtn);
        scanBtn.setOnClickListener(transfer);
        makeBtn.setOnClickListener(transfer);
    }

    Button.OnClickListener transfer = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v.getId()==R.id.scanBtn){
                Intent intent = new Intent(QrActivity.this, ScanActivity.class);
                startActivity(intent);
            }else if(v.getId()==R.id.makeBtn){
                Intent intent = new Intent(QrActivity.this, MakeActivity.class);
                startActivity(intent);
            }
        }
    };
}
