package com.example.clientapp.Gcm;

/**
 * Created by IVE on 2015-06-01.
 */
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.example.clientapp.Bluetooth.PushActivity;
import com.example.clientapp.R;
import com.google.android.gms.gcm.GcmListenerService;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GcmIntentService extends GcmListenerService {

    private NotificationManager mNotificationManager;
    NotificationCompat.Builder builder;
    public static final int NOTIFICATION_ID = 1;

    public GcmIntentService() {
    }

    @Override
    public void onMessageReceived(String from, Bundle data) {
        super.onMessageReceived(from, data);
        Log.i("YYH GCM RECEIVE", from);
        Log.i("YYH GCM RECEIVE", data.getString("message"));
        mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, PushActivity.class), 0);
        // notification의 진동의 경우 해제에 어려움이 있어 진동 서비스를 통해 직접 제어한다
        Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibe.vibrate(1500);
        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);  //벨

        Long now = System.currentTimeMillis();
        // 현재 시간을 저장 한다.
        Date date = new Date(now);
        // 시간 포맷 지정
        SimpleDateFormat CurDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String temp;
        String[] message = (data.getString("message")).split("!!");
        String content = "";
        if(message[1].equals("end")){
            content = "블루투스 연결이 끊켰습니다";
            temp = CurDateFormat.format(date)+" : 클라이언트(" + message[0] + ")의 연결이 끊켰습니다";
        }else{
            content =  "블루투스 연결이 시작되었습니다";
            temp = CurDateFormat.format(date)+" : 클라이언트(" + message[0] + ")가 연결되었습니다";
        }

        String log = getPreferences();
        if(log.length()>1){
            savePreferences(log+"\n"+temp);
        }else{
            savePreferences(temp);
        }
        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.drawable.ic_launcher)
                        .setContentTitle("블루투스 통신")
                        .setStyle(new NotificationCompat.BigTextStyle()
                                .bigText(content))
                        .setContentText(content).setSound(Uri.parse("android.resource://com.example.clientapp/" + R.raw.alram));

        mBuilder.setContentIntent(contentIntent);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
    }

    // 값 불러오기
    private String getPreferences(){
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        return pref.getString("Log", "");
    }

    // 값 저장하기
    private void savePreferences(String date){
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("Log", date);
        editor.commit();
    }
}