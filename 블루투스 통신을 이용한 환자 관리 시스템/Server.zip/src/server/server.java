package server;

import javax.microedition.io.*;
import javax.bluetooth.*;
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class server {
	public String deviceName = "";
	// start server
	private void startServer() throws IOException {
		StreamConnectionNotifier streamConnNotifier;
		StreamConnection connection;
		// Create a UUID for SPP
		UUID uuid = new UUID("1101", true);
		// Create the servicve url
		String connectionString = "btspp://localhost:" + uuid
				+ ";name=SPP Server";

		// open server url
		streamConnNotifier = (StreamConnectionNotifier) Connector
				.open(connectionString);

		// Wait for client connection
		System.out
				.println("\nServer Started. Waiting for clients to connect..");
		while (true) {
			connection = streamConnNotifier.acceptAndOpen();

			RemoteDevice dev = RemoteDevice.getRemoteDevice(connection);
			System.out.println("Remote device address: "
					+ dev.getBluetoothAddress());
			System.out.println("Remote device name: "
					+ dev.getFriendlyName(true));
			deviceName = dev.getFriendlyName(true);
			sendPush(true);

			// read string from spp client
			InputStream inStream = connection.openInputStream();
			BufferedReader bReader = new BufferedReader(new InputStreamReader(
					inStream));
			String lineRead = bReader.readLine();
			System.out.println(lineRead);

			while (true) {
				lineRead = bReader.readLine();
				if (lineRead != null) {
					System.out.println(lineRead);
				}else {
					System.out.println("Disconnection");
					sendPush(false);
					break;
				}
			}
			connection.close();
			
		}
		//streamConnNotifier.close();
	}
	
	public void sendPush(boolean flag) {
		String id = "";
		try {
			File myFile = new File("/home/pi/keyList.txt"); // 파일을 나타내는 File 객체
			if(myFile.exists()){
				FileReader fileReader = new FileReader(myFile);
				BufferedReader reader = new BufferedReader(fileReader);
				id = reader.readLine();
				System.out.println("Push Key : " + id);
				reader.close();
			}else{
				System.out.println("Push Key is not exist");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		System.out.println("Notification start : " + id);
		//서버 아이디
		Sender sender = new Sender("AIzaSyCDetbQC68Bb-fKxPi4NikUdVMl0QSj9bE");
		String message;
		if(flag){
			// 서버와 클라이언트의 블루투스 연결이 성공한 경우
			message = deviceName + "!!start";
		}else{
			message = deviceName + "!!end";
		}
		
		Message msg = new Message.Builder().addData("message", message)
				.build();

		try {
			Result result = sender.send(msg, id,1);
			if (result.getMessageId() != null) {
				// 푸시 전송 성공
				System.out.println("Notification is completed.");
			} else {
				String error = result.getErrorCodeName();
				System.out.println(error);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException {

		// display local device address and name
		LocalDevice localDevice = LocalDevice.getLocalDevice();
		System.out.println("Address: " + localDevice.getBluetoothAddress());
		System.out.println("Name: " + localDevice.getFriendlyName());

		server sampleSPPServer = new server();
		sampleSPPServer.startServer();
	}
}