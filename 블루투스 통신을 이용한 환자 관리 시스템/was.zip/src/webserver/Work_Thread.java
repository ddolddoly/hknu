package webserver;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;

public class Work_Thread extends Thread {

	// 클라이언트와의 접속 소켓
	private Socket connectionSocket;

	public Work_Thread(Socket connectionSocket) {
		this.connectionSocket = connectionSocket;
	}

	@Override
	public void run() {
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(
					this.connectionSocket.getInputStream()));
			String str = in.readLine();
			System.out.println("S: Received: '" + str + "'");
			File f = new File("/home/pi/keyList.txt");
			// 파일 존재 여부 판단
		    if (f.isFile()) {
		      f.delete();
		    }
			FileWriter fw = new FileWriter("keyList.txt");
			fw.write(str);
			fw.flush();
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}