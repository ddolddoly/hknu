package com.example.video_jpg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;

public class DrawTouchView extends View {

	public static Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

	public static int initX, initY,outitX,outitY, radius;
	public static float x,y;

	//public static Object canvas;
	private boolean drawing = false;
//	public static int x_coo [] = new int [100000];
//	public static int y_coo [] = new int [100000];

	public DrawTouchView(Context context) {
		super(context);
		if(!isInEditMode())
			init();
	}

	public DrawTouchView(Context context, AttributeSet attrs) {
		super(context, attrs);
		if(!isInEditMode())
			init();
	}

	public DrawTouchView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		if(!isInEditMode())
			if(!isInEditMode())init();
	}

	public static void init() {
		paint.setStyle(Paint.Style.STROKE);
		paint.setStrokeWidth(3);
		paint.setColor(Color.RED);
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec),
				MeasureSpec.getSize(heightMeasureSpec));
	}

	@Override
	protected void onDraw(Canvas canvas) {
		if(Catch_coordinate.bmp2!=null){
			canvas.drawBitmap(Catch_coordinate.bmp2, 0, 0, paint);}
		if (drawing) {
			//canvas.drawCircle(initX, initY, radius, paint);
			canvas.drawRect(initX, initY, outitX, outitY, paint);
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {

		int action = event.getAction();
		
		try {
			if (action == MotionEvent.ACTION_MOVE) {
				x = event.getX();
				y = event.getY();

//				radius = (float) Math.sqrt(Math.pow(x - initX, 2)
//						+ Math.pow(y - initY, 2));


			} else if (action == MotionEvent.ACTION_DOWN) {
				initX = (int)event.getX();
				initY = (int)event.getY();
				radius = 1;
				drawing = true;
			} else if (action == MotionEvent.ACTION_UP) {
				outitX = (int)event.getX();
				outitY = (int)event.getY();
				drawing = true;
				performClick();
			}
			invalidate();
		} catch (Exception illegalException) {
			if(Catch_coordinate.bmp2.getWidth()<Catch_coordinate.bmp2.getHeight()){//���λ���
				if(initX+x>600)
					outitX=initX+(600-initX);
				if(initY+y>800)
					outitY=initY+(800-initY);
			}else{ //���λ���
				if(initX+x>800)
					outitX=initX+(800-initX);
				if(initY+y>600)
					outitY=outitY+(600-initY);
			}
				
			
			

		}
		return true;
	}

	@Override
	public boolean performClick() {
		return super.performClick();
	}
	
	public static void bring_area() {
		Bitmap or_bit = Catch_coordinate.bmp2;
		Catch_coordinate.image_candidate.clear();
		int nWidth = outitX-initX;
		int nHeight = outitY-initY;
		int n=0;
		for (int i = 0; i < MainActivity.videoframes.size(); i++) {
			int[] nPixels = new int[nWidth * nHeight];
				MainActivity.videoframes.get(n).getPixels(nPixels, 0, nWidth,
						initX, initY, nWidth, nHeight);
				Bitmap newbit = Bitmap.createBitmap(nWidth, nHeight,
						Bitmap.Config.ARGB_8888);
				newbit.setPixels(nPixels, 0, nWidth, 0, 0, nWidth, nHeight);

				Catch_coordinate.image_candidate.add(newbit);

				n = n + 1;
		}
	}
	

	
	
		
//	---------������ ���� ��
	 
//		double distance=0;
//		int n=0;
//		for (int i = (int) (initX2 - radius); i <= (int)(initX2 + radius); i++) {
//			for (int j = (int) (initY2 - radius); j <= (int)(initY2 + radius); j++) {
//				distance = Math.sqrt((initX2-i)*(initX2-i)+(initY2-j)*(initY2-j));
//				if (radius>=distance){
//					x_coo[n]=i;
//					y_coo[n]=j;
//					n++;			
//				}
//			}
//		}


	// boolean onTouchEvent(View v, MotionEvent event) {
	// switch (event.getAction()) {
	// case MotionEvent.ACTION_DOWN:
	// start_eventX = (int) event.getX();
	// start_eventY = (int) event.getY();
	// mImgXY[0] = (int) bmp2.getWidth();
	// mImgXY[1] = (int) bmp2.getHeight();
	//
	// if (mImgXY[0] > mImgXY[1]) {
	// viewX = ci.getWidth();
	// viewY = viewX * 3 / 4;
	// } else {
	// viewX = ci.getWidth();
	// viewY = viewX * 4 / 3;
	// }
	// startX = eventX(start_eventX);
	// startY = eventY(start_eventY);
	//
	// break;
	//
	// case MotionEvent.ACTION_MOVE:
	// case MotionEvent.ACTION_UP:
	// stop_eventX = (int) event.getX();
	// stop_eventY = (int) event.getY();
	// stopX = eventX(stop_eventX);
	// stopY = eventY(stop_eventY);
	// start.setText("startX= " + startX + " , startY= " + startY
	// + "\nstopX= " + stopX + " , stopY= " + stopY);
	// //this.invalidate();
	// break;
	// }
	//
	// return super.onTouchEvent(event);
	// }
	//
	// public int eventX(int x) {
	// for (int i = 0; i <= mImgXY[0]; i++) {
	// if (x < ((viewX / mImgXY[0]) * (i + 1))
	// && x >= ((viewX / mImgXY[0]) * i))
	// ex = i;
	// }
	// return ex;
	// }
	//
	// public int eventY(int y) {
	// for (int i = 0; i <= mImgXY[1]; i++) {
	// if (y < ((viewY / mImgXY[1]) * (i + 1))
	// && y >= ((viewY / mImgXY[1]) * i))
	// ey = i;
	// }
	// return ey;
	// }

	/*
	 * public void onDraw(Canvas canvas) { super.onDraw(canvas); //onDraw��
	 * activity��ӹ޾Ƽ��� �ȵȴٳ�... �Ф�
	 * 
	 * paint = new Paint(); paint.setAntiAlias(true);
	 * paint.setStrokeWidth(5); paint.setStyle(Paint.Style.STROKE);
	 * paint.setColor(Color.YELLOW);
	 * 
	 * Rect rect = new Rect(startX, startX, stopX, stopY);
	 * canvas.drawRect(rect, paint); }
	 */

}