package com.example.video_jpg;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

import com.example.video_jpg.R;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuffXfermode;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory.Options;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Catch_coordinate extends Activity {

	public static Bitmap bmp2, cha_bmp2;
	public static TextView org,upd;
	public static ImageButton cho, cha, save, big, small, up, down, left, right;
	public static ImageView ch1, ch2, ch3, ch4, ch5, cha_img;
	 public static DrawTouchView cus_view;
	public static ArrayList<Bitmap> image_candidate = new ArrayList<Bitmap>();
	static int n = 0;

	// int start_eventX = 0;
	// int start_eventY = 0;
	// int stop_eventX = 0;
	// int stop_eventY = 0;
	// int viewX = 0;
	// int viewY = 0;
	// int startX = 0;
	// int startY = 0;
	// int stopX = 0;
	// int stopY = 0;
	// private int ex;
	// private int ey;
	// private int mImgXY[] = new int[2];

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); // ȭ��
																				// ���
																				// Ŀ����
		setContentView(R.layout.catch_coordinate);

		bmp2 = MainActivity.bmp2;
			
		cha_bmp2 = MainActivity.bmp2.copy(Bitmap.Config.ARGB_8888, true);

		cho = (ImageButton) findViewById(R.id.imageButton5);
		cha = (ImageButton) findViewById(R.id.imageButton7);
		save = (ImageButton) findViewById(R.id.imageButton9);
	
		ch1 = (ImageView) findViewById(R.id.imageView1);
		ch2 = (ImageView) findViewById(R.id.imageView2);
		ch3 = (ImageView) findViewById(R.id.imageView3);
		ch4 = (ImageView) findViewById(R.id.imageView4);
		ch5 = (ImageView) findViewById(R.id.imageView5);
		cha_img = (ImageView) findViewById(R.id.imageView6);
		
		org = (TextView)findViewById(R.id.textView2);
		upd = (TextView)findViewById(R.id.textView3);
		Typeface face = Typeface.createFromAsset(getAssets(), "nanoom_Bold.ttf");
		org.setTypeface(face);
		upd.setTypeface(face);
		
		ch1.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				n = 0;
				return false;
			}
		});

		ch2.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				n = 1;
				return false;
			}
		});

		ch3.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				n = 2;
				return false;
			}
		});

		ch4.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				n = 3;
				return false;
			}
		});

		ch5.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				n = 4;
				return false;
			}
		});

		cho.setOnTouchListener(new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				DrawTouchView.bring_area();
				if(image_candidate.size()==5){
					ch1.setImageBitmap(image_candidate.get(0));
					ch2.setImageBitmap(image_candidate.get(1));
					ch3.setImageBitmap(image_candidate.get(2));
					ch4.setImageBitmap(image_candidate.get(3));
					ch5.setImageBitmap(image_candidate.get(4));
				}
				
				if(image_candidate.size()==4){
					ch1.setImageBitmap(image_candidate.get(0));
					ch2.setImageBitmap(image_candidate.get(1));
					ch3.setImageBitmap(image_candidate.get(2));
					ch4.setImageBitmap(image_candidate.get(3));
					ch5.setClickable(false);
				}

				if(image_candidate.size()==3){
					ch1.setImageBitmap(image_candidate.get(0));
					ch2.setImageBitmap(image_candidate.get(1));
					ch3.setImageBitmap(image_candidate.get(2));
					ch4.setClickable(false);
					ch5.setClickable(false);
				}
				
				if(image_candidate.size()==2){
					ch1.setImageBitmap(image_candidate.get(0));
					ch2.setImageBitmap(image_candidate.get(1));
					ch3.setClickable(false);
					ch4.setClickable(false);
					ch5.setClickable(false);
				}
				
				if(image_candidate.size()==1){
					ch1.setImageBitmap(image_candidate.get(0));
					ch2.setClickable(false);
					ch3.setClickable(false);
					ch4.setClickable(false);
					ch5.setClickable(false);
				}

				return false;
			}
		});

		cha.setOnTouchListener(new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				change_area();
				return false;
			}
		});

		save.setOnTouchListener(new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				saveBitmaptoJpeg(cha_bmp2, "VIDEO_JPG", date());
				return false;
			}
		});

	}


	public static void change_area() {
		int wid = image_candidate.get(n).getWidth();
		int hei = image_candidate.get(n).getHeight();
		int[] pix = new int[wid * hei];
		image_candidate.get(n).getPixels(pix, 0, wid, 0, 0, wid, hei);
		cha_bmp2.setPixels(pix, 0, wid, DrawTouchView.initX,
				DrawTouchView.initY, wid, hei);
		cha_img.setImageBitmap(cha_bmp2);

	}

	public void saveBitmaptoJpeg(Bitmap bitmap, String folder, String name) {
		String ex_storage = Environment.getExternalStorageDirectory()
				.getAbsolutePath();
		// Get Absolute Path in External Sdcard
		String foler_name = "/" + folder + "/";
		String file_name = name + ".jpg";
		String string_path = ex_storage + foler_name;

		File file_path;
		try {
			file_path = new File(string_path);
			if (!file_path.isDirectory()) {
				file_path.mkdirs();
			}
			FileOutputStream out = new FileOutputStream(string_path + file_name);

			bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
			Toast.makeText(Catch_coordinate.this, "������ ����Ǿ����ϴ�.",
					Toast.LENGTH_SHORT).show();
			out.close();

		} catch (FileNotFoundException exception) {
			Log.e("FileNotFoundException", exception.getMessage());
		} catch (IOException exception) {
			Log.e("IOException", exception.getMessage());
		}
	}

	public String date() {
		String date;
		int curyear, curmonth, curdate, curhour, curmin, cursec;
		Calendar c = Calendar.getInstance();
		curyear = c.get(Calendar.YEAR);
		curmonth = c.get(Calendar.MONTH);
		curdate = c.get(Calendar.DAY_OF_MONTH);
		curhour = c.get(Calendar.HOUR_OF_DAY);
		curmin = c.get(Calendar.MINUTE);
		cursec = c.get(Calendar.SECOND);
		date = curyear + "." + curmonth + "." + curdate + "_" + curhour + ":"
				+ curmin + ":" + cursec;
		return date;
	}

	// --------------------------------- ������ �ڸ���!!!
	// public ArrayList make_images(){
	// int n=0;
	// int k=0;
	// int ff=255;
	// for(int i=0;i<5;i++){
	// int [][] pixels = new int[bmp2.getHeight()][bmp2.getWidth()];
	// int newPixels[] = new int[bmp2.getHeight()*bmp2.getWidth()];
	// Bitmap image = MainActivity.videoframes.get(n);
	// for(int j =0; j<bmp2.getHeight();j++){
	// pixels[DrawTouchView.x_coo[j]][DrawTouchView.y_coo[j]] =
	// image.getPixel(DrawTouchView.y_coo[j], DrawTouchView.x_coo[j]);
	//
	// int red = (pixels[i][j] & 0xff0000) / 0x10000;
	// int green = (pixels[i][j] & 0xff00) / 0x100;
	// int blue = pixels[i][j] & 0xff;
	//
	// // �ٽ� ��ġ��
	// // newPixels[i]=Color.rgb(red, green, blue);
	// newPixels[k] = ff * 0x1000000 + red * 0x10000 + green
	// * 0x100 + blue;
	// k++;
	//
	// }
	// n=n+4;
	// Bitmap newbit = Bitmap.createBitmap(newPixels, 0, bmp2.getWidth(),
	// bmp2.getWidth(), bmp2.getHeight(), Bitmap.Config.RGB_565);
	// image_candidate.add(newbit);
	// }
	// return image_candidate;
	// }

}
