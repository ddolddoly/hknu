package com.example.video_jpg;

import com.example.video_jpg.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

public class intro extends Activity {

	ImageView iv_intro;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.intro);
		iv_intro = (ImageView)findViewById(R.id.iv_intro);

		//�ڵ鷯
	    Handler mHandler = new Handler(); 
	    mHandler.postDelayed(new Runnable() { 
	        @Override 
	        public void run() { 
	            // TODO Auto-generated method stub 
	        	//���� ���� ��Ƽ��Ƽ, �ڰ� �̵��� ��Ƽ��Ƽ
	            Intent i = new Intent(intro.this, MainActivity.class); 
	            startActivity(i); 
	            finish(); 
	        } 
	    }, 1500); // 1500ms 
	}
}
