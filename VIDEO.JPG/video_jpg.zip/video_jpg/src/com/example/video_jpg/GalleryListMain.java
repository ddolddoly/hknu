package com.example.video_jpg;

import java.io.File;
import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class GalleryListMain extends Activity {
	ProgressDialog mLoagindDialog;
	GridView mGvImageList;
	ImageAdapter mListAdapter;
	ArrayList<GalleryItem> mThumbImageInfoList;
	ArrayList<String> g_image;
	ImageButton ok, can;
	TextView txt;
	ArrayList<String> tmp;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gallery_list);

		mThumbImageInfoList = new ArrayList<GalleryItem>();
		g_image= new ArrayList<String>();
		mGvImageList = (GridView) findViewById(R.id.gvImageList);
		ok = (ImageButton) findViewById(R.id.imageButton1);
		can = (ImageButton) findViewById(R.id.imageButton2);
		tmp = new ArrayList<String>();
		txt = (TextView)findViewById(R.id.textView1);
		txt.setTypeface(Typeface.createFromAsset(getAssets(), "nanoom_Bold.ttf"));
		txt.setText("���ϴ� ������ 5���̳��� �������ּ���.");
		new DoFindImageList().execute();
		
		ok.setOnTouchListener(new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				tmp = path();
				Intent intent = new Intent(GalleryListMain.this,
						MainActivity.class);		

				if (tmp.size()==5) {
					intent.putExtra("iv1", tmp.get(0));
					intent.putExtra("iv2", tmp.get(1));
					intent.putExtra("iv3", tmp.get(2));
					intent.putExtra("iv4", tmp.get(3));
					intent.putExtra("iv5", tmp.get(4));
					startActivity(intent); 
					MainActivity.ox = true;
					finish();
				}
				
				if (tmp.size()==4) {
					intent.putExtra("iv1", tmp.get(0));
					intent.putExtra("iv2", tmp.get(1));
					intent.putExtra("iv3", tmp.get(2));
					intent.putExtra("iv4", tmp.get(3));
					startActivity(intent); 
					MainActivity.ox = true;
					finish();
				}
				
				if (tmp.size()==3) {
					intent.putExtra("iv1", tmp.get(0));
					intent.putExtra("iv2", tmp.get(1));
					intent.putExtra("iv3", tmp.get(2));
					startActivity(intent); 
					MainActivity.ox = true;
					finish();
				}
				
				if (tmp.size() == 2) {
					intent.putExtra("iv1", tmp.get(0));
					intent.putExtra("iv2", tmp.get(1));
					startActivity(intent); 
					MainActivity.ox = true;
					finish();
				}

				if (tmp.size() == 1) {
					intent.putExtra("iv1", tmp.get(0));
					startActivity(intent); 
					MainActivity.ox = true;
					finish();
				}
				return true;
			}
		});
		
		can.setOnTouchListener(new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				finish();
				return true;
			}
		});

	}
	
	public ArrayList<String> path() {
		ArrayList<String> g_path = new ArrayList<String>();
		for(int i =0;i<mThumbImageInfoList.size();i++){
			if(mThumbImageInfoList.get(i).getCheckedState()==true)
				g_path.add(mThumbImageInfoList.get(i).getData());
		}
		return g_path;
	}


	private long findThumbList() {
		long returnValue = 0;

		// Select �ϰ��� �ϴ� �÷�
		String[] projection = { MediaStore.Images.Media._ID,
				MediaStore.Images.Media.DATA };

		// ���� ����
		@SuppressWarnings("deprecation")
		Cursor imageCursor = managedQuery(
				MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null,
				null, MediaStore.Images.Media.DATE_ADDED + " desc ");

		if (imageCursor != null && imageCursor.getCount() > 0) {
			// �÷� �ε���
			int imageIDCol = imageCursor
					.getColumnIndex(MediaStore.Images.Media._ID);
			int imageDataCol = imageCursor
					.getColumnIndex(MediaStore.Images.Media.DATA);

			// Ŀ������ �̹����� ID�� ��θ��� �����ͼ� GalleryItem �� Ŭ������ �����ؼ�
			// ����Ʈ�� �����ش�.
			while (imageCursor.moveToNext()) {
				GalleryItem thumbInfo = new GalleryItem();

				thumbInfo.setId(imageCursor.getString(imageIDCol));
				thumbInfo.setData(imageCursor.getString(imageDataCol));
				thumbInfo.setCheckedState(false);

				mThumbImageInfoList.add(thumbInfo);
				returnValue++;
			}
		}
		//imageCursor.close();
		imageCursor=null;
		return returnValue;
	}

	// ȭ�鿡 �̹������� �ѷ��ش�.
	private void updateUI() {
		mListAdapter = new ImageAdapter(this, R.layout.gallery_cell,
				mThumbImageInfoList);
		mGvImageList.setAdapter(mListAdapter);
	}

	// *****************************************************************************************
	// //
	// Image Adapter Class
	// *****************************************************************************************
	// //
	static class ImageViewHolder {
		ImageView ivImage;
		CheckBox chkImage;
	}

	private class ImageAdapter extends BaseAdapter {
		private Context mContext;
		private int mCellLayout;
		private LayoutInflater mLiInflater;
		private ArrayList<GalleryItem> mThumbImageInfoList;
		
		private String imgData;
        private String geoData;
        private ArrayList<String> thumbsDataList;
        private ArrayList<String> thumbsIDList;

		public ImageAdapter(Context c, int cellLayout,
				ArrayList<GalleryItem> thumbImageInfoList) {
			mContext = c;
			mCellLayout = cellLayout;
			mThumbImageInfoList = thumbImageInfoList;

			thumbsDataList = new ArrayList<String>();
            thumbsIDList = new ArrayList<String>();
			mLiInflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		public int getCount() {
			return mThumbImageInfoList.size();
		}

		public Object getItem(int position) {
			return mThumbImageInfoList.get(position);
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(final int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = mLiInflater.inflate(mCellLayout, parent, false);
				ImageViewHolder holder = new ImageViewHolder();

				holder.ivImage = (ImageView) convertView
						.findViewById(R.id.ivImage);
				holder.chkImage = (CheckBox) convertView
						.findViewById(R.id.chkImage);

				convertView.setTag(holder);
			}

			final ImageViewHolder holder = (ImageViewHolder) convertView
					.getTag();

			if (((GalleryItem) mThumbImageInfoList.get(position))
					.getCheckedState())
				holder.chkImage.setChecked(true);
			else
				holder.chkImage.setChecked(false);
			
			holder.ivImage.setImageBitmap(mThumbImageInfoList.get(position)
					.getBitmap());

			setProgressBarIndeterminateVisibility(false);

			convertView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {

					if (mThumbImageInfoList.get(position).getCheckedState() == true) {
						mThumbImageInfoList.get(position)
								.setCheckedState(false);
					} else {
						mThumbImageInfoList.get(position).setCheckedState(true);
					}
					mListAdapter.notifyDataSetChanged();
				}
			});

			try {
				String path = ((GalleryItem) mThumbImageInfoList
						.get(position)).getData();
//				System.out.println(path);
//				String imgPath = getImageInfo(imgData, geoData, thumbsIDList.get(position));
//				g_image.add(path);
				BitmapFactory.Options option = new BitmapFactory.Options();

				if (new File(path).length() > 100000)
					option.inSampleSize = 10;
				else
					option.inSampleSize = 2;

				Bitmap bmp = BitmapFactory.decodeFile(path, option);
				holder.ivImage.setImageBitmap(bmp);

				setProgressBarIndeterminateVisibility(false);
			} catch (Exception e) {
				e.printStackTrace();
				setProgressBarIndeterminateVisibility(false);
			}

			return convertView;
		}
	}

	// *****************************************************************************************
	// //
	// Image Adapter Class End
	// *****************************************************************************************
	// //

	 private String getImageInfo(String ImageData, String Location, String thumbID){
         String imageDataPath = null;
         String[] proj = {MediaStore.Images.Media._ID,
                  MediaStore.Images.Media.DATA,
                  MediaStore.Images.Media.DISPLAY_NAME,
                  MediaStore.Images.Media.SIZE};
         Cursor imageCursor = managedQuery(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                 proj, "_ID='"+ thumbID +"'", null, null);
          
         if (imageCursor != null && imageCursor.moveToFirst()){
             if (imageCursor.getCount() > 0){
                 int imgData = imageCursor.getColumnIndex(MediaStore.Images.Media.DATA);
                 imageDataPath = imageCursor.getString(imgData);
             }
         }
         imageCursor.close();
         return imageDataPath;
     }

	// *****************************************************************************************
	// //
	// AsyncTask Class
	// *****************************************************************************************
	// //
	private class DoFindImageList extends AsyncTask<String, Integer, Long> {
		@Override
		protected void onPreExecute() {
			mLoagindDialog = ProgressDialog.show(GalleryListMain.this, null, "�ε���...",
					true, true);
			super.onPreExecute();
		}

		@Override
		protected Long doInBackground(String... arg0) {
			long returnValue = 0;
			returnValue = findThumbList();
			return returnValue;
		}

		@Override
		protected void onPostExecute(Long result) {
			updateUI();
			mLoagindDialog.dismiss();
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
		}
	}
	// *****************************************************************************************
	// //
	// AsyncTask Class End
	// *****************************************************************************************
	// //
}