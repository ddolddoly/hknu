package com.example.video_jpg;

//import java.io.File;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.sql.Time;
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.List;
//
//import com.example.video_jpg.R;
//
//import android.media.MediaMetadataRetriever;
//import android.media.MediaPlayer;
//import android.net.Uri;
//import android.os.Bundle;
//import android.os.Environment;
//import android.view.Menu;
//import android.view.MenuItem;
//import android.view.MotionEvent;
//import android.view.ViewGroup.LayoutParams;
//import android.provider.MediaStore;
//import android.app.Activity;
//import android.app.AlertDialog;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.content.res.Resources;
//import android.graphics.Bitmap;
//import android.graphics.Bitmap.CompressFormat;
//import android.graphics.BitmapFactory;
//import android.graphics.Canvas;
//import android.graphics.Paint;
//import android.graphics.PorterDuff.Mode;
//import android.graphics.PorterDuffXfermode;
//import android.graphics.drawable.BitmapDrawable;
//import android.view.View;
//import android.widget.AdapterView;
//import android.widget.AdapterView.OnItemClickListener;
//import android.widget.Button;
//import android.widget.HorizontalScrollView;
//import android.widget.ImageButton;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//import android.widget.Toast;
//
//public class MainActivity extends Activity {
//	public static Bitmap bmp2;
//	public static MediaMetadataRetriever mmRetriever;
//	public static ArrayList<Bitmap> videoframes;
//	public static Uri mImageMovieUri;
//	public static String uri;
//	HorizontalScrollView horizontalScrollView;
//	ImageView main,iv1,iv2,iv3,iv4,iv5;
//	//��� ���ȴ��� �����ϴº���
//	ImageButton btn;
//	int cnt=0;
//	int n=0;
//	Thread thread;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//    	
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.main);
//     
//        main = (ImageView) findViewById(R.id.imageView);
//        iv1 = (ImageView) findViewById(R.id.iv1);
//        iv2 = (ImageView) findViewById(R.id.iv2);
//        iv3 = (ImageView) findViewById(R.id.iv3);
//        iv4 = (ImageView) findViewById(R.id.iv4);
//        iv5 = (ImageView) findViewById(R.id.iv5);
//        
//        horizontalScrollView = (HorizontalScrollView)findViewById(R.id.horizontalScrollView1);
//        horizontalScrollView.setHorizontalScrollBarEnabled(true);
//
//	   Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
//	   //������ ǰ��
//	   intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY,1);
//	   //������ �ð� ����
//	   intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT,2);
//	   //������ �뷮 ����
//	   intent.putExtra(MediaStore.EXTRA_SIZE_LIMIT, (long)(1024 * 1024 * 10));// �뷮 5491520L 10485760
//	   //������ ���� ���
////	   File file_path = new File(uri);
////	   if(!file_path.isDirectory())
////		   file_path.mkdirs();
//
//	    mImageMovieUri = Uri.fromFile(new File(Environment.getExternalStorageDirectory(),"VIDEO_JPG"+".mp4"));
//		intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
//		mImageMovieUri);
//		startActivityForResult(intent, 2);
//
//    }
//    
//	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
//		super.onActivityResult(requestCode, resultCode, intent);
//		if(resultCode!=RESULT_CANCELED){
//			if(requestCode == 2) {
//				System.out.println("asdfffffffffffffffffffffff");
//				frame();
//			}
//		}
//	}
//
//	
//	 public void frame(){
//	      // �������� ��������
//	        //File myVideo = new File(uri, "VIDEO_JPG.mp4");
//	        // ���� ������ uri
//	        //Uri myVideoUri = Uri.parse(myVideo.toString());
//	     
////	        mmRetriever = new MediaMetadataRetriever();
////	        mmRetriever.setDataSource(myVideo.getAbsolutePath());
////	        mmRetriever.setDataSource(uri+"VIDEO_JPG.mp4");
////	        add_lists();
//		 
//		 File myVideo = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "VIDEO_JPG.mp4");
//	     	// ���� ������ uri
//	     	Uri myVideoUri = Uri.parse(myVideo.toString());
//
//	     
//	     	MediaMetadataRetriever mmRetriever = new MediaMetadataRetriever();
//	     	mmRetriever.setDataSource(myVideo.getAbsolutePath());
//	     	     	// �������� �ֱ�����  ArrayList
//
//	        for(int i = 0; i <=6; i+=1000){
//
//	            // getFrameAtTime �Լ��� i ��� Ÿ�ӿ� bitmap�� �����ش�.(
//
//	            // getFrameAtTime�� ù��° ������ unit �� microsecond�̴�.
//
//	            // �׷��� 1000�� �����־���.
//
//	           Bitmap bitmap = mmRetriever.getFrameAtTime(i*400000,MediaMetadataRetriever.OPTION_CLOSEST);
//	           if(bitmap.getHeight()<bitmap.getWidth())
//	    			bitmap = resizeBitmapImageFn(bitmap,960,720);
//	    		if(bitmap.getHeight()>960 && bitmap.getWidth()>720)
//	    			bitmap = resizeBitmapImageFn(bitmap,720,960);
//	            videoframes.add(bitmap);
//
//	        }
//
//	        // retreiver�� �� ����ߴٸ� release�� ���־���Ѵ�.
//
//	        mmRetriever.release();
//	        divisionFrame();
//
//	    }
//	        
//				
////    public void add_lists(){
////    	// �������� �ֱ�����  ArrayList
////    	videoframes = new ArrayList<Bitmap>();
////		for(int i = 1; i < 6; i++){
////     		Bitmap bitmap = mmRetriever.getFrameAtTime(400000*i,MediaMetadataRetriever.OPTION_CLOSEST);
////     		if(bitmap.getHeight()<bitmap.getWidth())
////    			bitmap = resizeBitmapImageFn(bitmap,960,720);
////    		if(bitmap.getHeight()>960 && bitmap.getWidth()>520)
////    			bitmap = resizeBitmapImageFn(bitmap,720,960);
////     		videoframes.add(bitmap);
////     	}
////     	divisionFrame();
////	}
//	public void divisionFrame(){
//
//		iv1.setImageBitmap((Bitmap)videoframes.get(0));
//		iv2.setImageBitmap((Bitmap)videoframes.get(1));
//		iv3.setImageBitmap((Bitmap)videoframes.get(2));
//		iv4.setImageBitmap((Bitmap)videoframes.get(3));
//		iv5.setImageBitmap((Bitmap)videoframes.get(4));
//		
//       iv1.setOnTouchListener(new View.OnTouchListener() {
//			@Override
//			public boolean onTouch(View v, MotionEvent event) {
//				// TODO Auto-generated method stub
//				main.setImageBitmap((Bitmap)videoframes.get(0));
//				n=0;
//				return false;
//			}
//		});
//       
//       iv2.setOnTouchListener(new View.OnTouchListener() {
//			public boolean onTouch(View v, MotionEvent event) {
//				main.setImageBitmap((Bitmap)videoframes.get(1));
//				n=1;
//				return false;
//			}
//		});
//       
//       iv3.setOnTouchListener(new View.OnTouchListener() {
//			public boolean onTouch(View v, MotionEvent event) {
//				main.setImageBitmap((Bitmap)videoframes.get(2));
//				n=2;
//				return false;
//			}
//		});
//       
//       iv4.setOnTouchListener(new View.OnTouchListener() {
//			public boolean onTouch(View v, MotionEvent event) {
//				main.setImageBitmap((Bitmap)videoframes.get(3));
//				n=3;
//				return false;
//			}
//		});
//       
//       iv5.setOnTouchListener(new View.OnTouchListener() {
//			public boolean onTouch(View v, MotionEvent event) {
//				main.setImageBitmap((Bitmap)videoframes.get(4));
//				n=4;
//				return false;
//			}
//		});
//       
//       main.setOnTouchListener(new View.OnTouchListener() {
//
//			@Override
//			public boolean onTouch(View v, MotionEvent event) {
//				// TODO Auto-generated method stub
//				cnt++;
//				if(cnt!=0){
//					//Toast toast = Toast.makeText(MainActivity.this, "�ǳ�?", Toast.LENGTH_SHORT);
//					//toast.show(); 
//					cnt=0;
//					DialogSimple();
//					
//					//finish();
//				}
//
//				return false;
//			}
//		});
//       
//    }
//     
//	public Bitmap resizeBitmapImageFn(Bitmap bmpSource, int w, int h) {
//		int iWidth   = w;   // ��ҽ�ų �ʺ�
//		int iHeight  = h;   // ��ҽ�ų ����
//		float fWidth  = bmpSource.getWidth();
//		float fHeight = bmpSource.getHeight();
//
//		// ���ϴ� ���̺��� Ŭ ����� ����
//		if(fWidth > iWidth) {
//		    float mWidth = (float) (fWidth / 100);
//		    float fScale = (float) (iWidth / mWidth);
//		    fWidth *= (fScale / 100);
//		    fHeight *= (fScale / 100);
//
//		// ���ϴ� ���̺��� Ŭ ����� ����
//		}else if (fHeight > iHeight) {
//		    float mHeight = (float) (fHeight / 100);
//		    float fScale = (float) (iHeight / mHeight);
//		    fWidth *= (fScale / 100);
//		    fHeight *= (fScale / 100);
//		}
//
//		return Bitmap.createScaledBitmap(bmpSource, (int)fWidth, (int)fHeight, true);
//
//	}
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//        if (id == R.id.action_settings) {
//            return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }
//
//   
//    private void DialogSimple(){
//        AlertDialog.Builder alt_bld = new AlertDialog.Builder(this);
//        alt_bld.setMessage("������ ���� �Ͻðڽ��ϱ�?").setCancelable(
//            false).setPositiveButton("��",
//            new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//                // Action for 'Yes' Button
//            	
//            	//Intent i= new Intent(MainActivity.this,CropImage_view.class);
//            	Intent i= new Intent(MainActivity.this,Catch_coordinate.class);
//				Bitmap bmp2;
//				i.putExtra("bmp2", (Bitmap)videoframes.get(n));
//				startActivity(i);
//            	
//            }
//            }).setNegativeButton("�ƴϿ�",
//            new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//                // Action for 'NO' Button
//                finish();
//            }
//            });
//        AlertDialog alert = alt_bld.create();
//        // Title for AlertDialog
//        alert.setTitle("Title");
//        // Icon for AlertDialog
//        alert.setIcon(R.drawable.ic_launcher);
//        alert.show();
//    }
//
//}

//package com.example.video_jpg;
//
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.example.video_jpg.R;

import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup.LayoutParams;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.BitmapDrawable;
import android.hardware.Camera;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	public static Bitmap bmp2;
	Bitmap myBitmap = null;
	public static boolean wide = true;
	public static ArrayList<Bitmap> videoframes;
	public static boolean ox = false;
	HorizontalScrollView horizontalScrollView;
	public static ImageView main, iv1, iv2, iv3, iv4, iv5, iv6, iv7, iv8, iv9,
			iv10;
	// ��� ���ȴ��� �����ϴº���
	ImageButton btn;
	int cnt = 0;
	int n = 0;
	Thread thread;

	// Intent intent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		// intent = new Intent(MainActivity.this,
		// GalleryListMain.class);
		videoframes = new ArrayList<Bitmap>();
		main = (ImageView) findViewById(R.id.imageView);

		iv1 = (ImageView) findViewById(R.id.iv1);
		iv1.setClickable(false);
		iv2 = (ImageView) findViewById(R.id.iv2);
		iv2.setClickable(false);
		iv3 = (ImageView) findViewById(R.id.iv3);
		iv3.setClickable(false);
		iv4 = (ImageView) findViewById(R.id.iv4);
		iv4.setClickable(false);
		iv5 = (ImageView) findViewById(R.id.iv5);
		iv5.setClickable(false);

		btn = (ImageButton) findViewById(R.id.imageButton1);

		horizontalScrollView = (HorizontalScrollView) findViewById(R.id.horizontalScrollView1);
		horizontalScrollView.setHorizontalScrollBarEnabled(true);

		if (ox == true) {
			Intent intent = getIntent();
			String i1 = intent.getStringExtra("iv1");
			System.out.println(i1);
			videoframes.add(trans_image(i1));
			iv1.setImageBitmap(trans_image(i1));

			String i2 = intent.getStringExtra("iv2");
			if (i2 == null) {
				iv2.setImageBitmap(null);
				iv2.setClickable(false);
			} else {
				videoframes.add(trans_image(i2));
				iv2.setImageBitmap(trans_image(i2));
			}

			String i3 = intent.getStringExtra("iv3");
			if (i3 == null) {
				iv3.setImageBitmap(null);
				iv3.setClickable(false);
			} else {
				videoframes.add(trans_image(i3));
				iv3.setImageBitmap(trans_image(i3));
			}

			String i4 = intent.getStringExtra("iv4");
			if (i4 == null) {
				iv4.setImageBitmap(null);
				iv4.setClickable(false);
			} else {
				videoframes.add(trans_image(i4));
				iv4.setImageBitmap(trans_image(i4));
			}

			String i5 = intent.getStringExtra("iv5");
			if (i5 == null) {
				iv5.setImageBitmap(null);
				iv5.setClickable(false);
			} else {
				videoframes.add(trans_image(i5));
				iv5.setImageBitmap(trans_image(i5));
			}

			iv1.setOnTouchListener(new View.OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					main.setImageBitmap(videoframes.get(0));
					n = 0;
					return true;
				}
			});

			iv2.setOnTouchListener(new View.OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					main.setImageBitmap(videoframes.get(1));
					n = 1;
					return true;
				}
			});

			iv3.setOnTouchListener(new View.OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					main.setImageBitmap(videoframes.get(2));
					n = 2;
					return true;
				}
			});

			iv4.setOnTouchListener(new View.OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					main.setImageBitmap(videoframes.get(3));
					n = 3;
					return true;
				}
			});

			iv5.setOnTouchListener(new View.OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					main.setImageBitmap(videoframes.get(4));
					n = 4;
					return true;
				}
			});

			main.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					DialogSimple();
					return false;
				}
			});
		}

		btn.setOnTouchListener(new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				Intent intent = new Intent(MainActivity.this,
						GalleryListMain.class);
				startActivity(intent);
				finish();
				return true;
			}
		});
	}

	public Bitmap trans_image(String s) {
		File imgFile = new File(s);
		if (imgFile.exists()) {
			myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
			if (myBitmap.getHeight() < myBitmap.getWidth()) {
				myBitmap = Bitmap.createScaledBitmap(myBitmap, 800, 600, false);
			}

			else {
				myBitmap = Bitmap.createScaledBitmap(myBitmap, 600, 800, false);
				wide = false;
			}
		}

		return myBitmap;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private void DialogSimple() {
		AlertDialog.Builder alt_bld = new AlertDialog.Builder(this);
		alt_bld.setMessage("������ ���� �Ͻðڽ��ϱ�?")
				.setCancelable(false)
				.setPositiveButton("��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						Intent i = new Intent(MainActivity.this,
								Catch_coordinate.class);
						bmp2 = (Bitmap) videoframes.get(n);
						startActivity(i);
						finish();

					}
				})
				.setNegativeButton("�ƴϿ�",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {

							}
						});
		AlertDialog alert = alt_bld.create();
		// Title for AlertDialog
		alert.setTitle("Title");
		// Icon for AlertDialog
		alert.setIcon(R.drawable.ic_launcher);
		alert.show();
	}

}

// package com.example.video_jpg;
//
// import java.io.File;
// import java.io.FileNotFoundException;
// import java.io.FileOutputStream;
// import java.io.IOException;
// import java.sql.Time;
// import java.util.ArrayList;
// import java.util.Calendar;
// import java.util.List;
//
// import com.example.video_jpg.R;
//
// import android.media.MediaMetadataRetriever;
// import android.media.MediaPlayer;
// import android.net.Uri;
// import android.os.Bundle;
// import android.os.Environment;
// import android.util.Log;
// import android.view.Menu;
// import android.view.MenuItem;
// import android.view.MotionEvent;
// import android.view.ViewGroup.LayoutParams;
// import android.provider.MediaStore;
// import android.provider.MediaStore.Images;
// import android.app.Activity;
// import android.app.AlertDialog;
// import android.content.ActivityNotFoundException;
// import android.content.Context;
// import android.content.DialogInterface;
// import android.content.Intent;
// import android.content.res.Resources;
// import android.graphics.Bitmap;
// import android.graphics.Bitmap.CompressFormat;
// import android.graphics.BitmapFactory;
// import android.graphics.Canvas;
// import android.graphics.Paint;
// import android.graphics.PorterDuff.Mode;
// import android.graphics.PorterDuffXfermode;
// import android.graphics.drawable.BitmapDrawable;
// import android.hardware.Camera;
// import android.view.View;
// import android.widget.AdapterView;
// import android.widget.AdapterView.OnItemClickListener;
// import android.widget.Button;
// import android.widget.HorizontalScrollView;
// import android.widget.ImageView;
// import android.widget.LinearLayout;
// import android.widget.TextView;
// import android.widget.Toast;
//
// public class MainActivity extends Activity {
// public Bitmap photo;
// public static Bitmap bmp2;
// private static final int PICK_FROM_CAMERA = 1;
// private static final int PICK_FROM_GALLERY = 2;
//
// Button camera, gallery;
// ImageView img;
//
// @Override
// protected void onCreate(Bundle savedInstanceState) {
//
// super.onCreate(savedInstanceState);
// setContentView(R.layout.activity_main);
//
// camera = (Button) findViewById(R.id.button1);
// gallery = (Button) findViewById(R.id.button2);
// img = (ImageView) findViewById(R.id.imageView1);
//
// camera.setOnClickListener(new View.OnClickListener() {
// public void onClick(View v) {
// Intent intent = new Intent();
// intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
// startActivityForResult(intent, PICK_FROM_CAMERA);
//
// }
// });
//
// gallery.setOnClickListener(new View.OnClickListener() {
// public void onClick(View v) {
//
// Intent intent = new Intent();
// // Gallery ȣ��
// intent.setType("image/*");
// intent.setAction(Intent.ACTION_GET_CONTENT);
// startActivityForResult(intent, PICK_FROM_GALLERY);
// }
// });
// }
//
// protected void onActivityResult(int requestCode, int resultCode, Intent data)
// {
//
// if (requestCode == PICK_FROM_CAMERA) {
// Bundle extras = data.getExtras(); // ī�޶󿡼� ���� �� ������ ��������
// photo = extras.getParcelable("data");
// if (data != null) {
// Log.e("Test", "result = " + data);
// Bitmap thumbnail = (Bitmap)data.getExtras().get("data");
// if (thumbnail != null) {
// img.setImageBitmap(thumbnail);
// }
// }
// }
// if (requestCode == PICK_FROM_GALLERY) {
// Bitmap photo = null;
// if (data != null) {
// Log.e("Test", "result = " + data);
// Uri thumbnail = data.getData();
// if (thumbnail != null) {
// try {
// photo=Images.Media.getBitmap(getContentResolver(), thumbnail);
// img.setImageBitmap(photo);
// Intent i = new Intent(MainActivity.this,
// Selected_images.class);
// bmp2 = photo;
// // bmp2 = Bitmap.createScaledBitmap(bmp2,
// // bmp2.getWidth()*2, bmp2.getHeight()*2, true);
// i.putExtra("bmp2", bmp2);
// startActivity(i);
// } catch (FileNotFoundException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// } catch (IOException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// }
// }
// }
// }
// }