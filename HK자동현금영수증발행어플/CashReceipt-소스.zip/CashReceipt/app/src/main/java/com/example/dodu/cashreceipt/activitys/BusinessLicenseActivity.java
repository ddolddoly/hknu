package com.example.dodu.cashreceipt.activitys;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.dodu.cashreceipt.R;
import com.example.dodu.cashreceipt.shPrefInfo.BusinessLicenseInfo;

/**
 * Created by dodu on 15. 5. 29..
 */
public class BusinessLicenseActivity extends Activity {

    private EditText et_representName, et_storeAddress, et_storeName;
    private EditText et_businessNumber01, et_businessNumber02, et_businessNumber03;
    private EditText et_businessType, et_businessCondition, et_phoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.business_license);

        init();
    }

    public void init() {

        Button btn_submit = (Button) findViewById(R.id.submit);
        Button btn_cancel = (Button) findViewById(R.id.cancel);

        et_representName = (EditText) findViewById(R.id.representName);
        et_storeName = (EditText) findViewById(R.id.storeName);
        et_businessNumber01 = (EditText) findViewById(R.id.businessNumber01);
        et_businessNumber02 = (EditText) findViewById(R.id.businessNumber02);
        et_businessNumber03 = (EditText) findViewById(R.id.businessNumber03);
        et_storeAddress = (EditText) findViewById(R.id.storeAddress);
        et_businessType = (EditText) findViewById(R.id.businessType);
        et_businessCondition = (EditText) findViewById(R.id.businessCondition);
        et_phoneNumber = (EditText) findViewById(R.id.contactNumber);

        View.OnClickListener btn_listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.submit :
                        submit(); break;
                    case R.id.cancel :
                        cancel(); break;
                }
            }
        };

        btn_submit.setOnClickListener(btn_listener);
        btn_cancel.setOnClickListener(btn_listener);
    }

    public void submit() {
        //
        String name = et_representName.getText().toString();
        String phoneNumber = et_phoneNumber.getText().toString();
        String address = et_representName.getText().toString();
        String storeName = et_storeName.getText().toString();
        String businessNumber = et_businessNumber01.getText().toString();
        businessNumber += "-"+et_businessNumber02.getText().toString();
        businessNumber += "-"+et_businessNumber03.getText().toString();

        String businessType = et_businessType.getText().toString();
        String businessCondition = et_businessCondition.getText().toString();

        BusinessLicenseInfo businessLicenseInfo = new BusinessLicenseInfo(getApplicationContext());
        businessLicenseInfo.saveData(name, phoneNumber, address, storeName, businessNumber, businessType, businessCondition);

        reset();

        Intent intent = new Intent(this, CashReceiveActivity.class);
        finish();
        startActivity(intent);
    }

    public void reset() {
        // TextField reset text.
        et_representName.setText("");
        et_storeName.setText("");
        et_businessNumber01.setText("");
        et_businessNumber02.setText("");
        et_businessNumber03.setText("");
        et_storeAddress.setText("");
        et_businessType.setText("");
        et_businessCondition.setText("");
        et_phoneNumber.setText("");
    }

    public void cancel() {
        // activity end.
        finish();
    }
}