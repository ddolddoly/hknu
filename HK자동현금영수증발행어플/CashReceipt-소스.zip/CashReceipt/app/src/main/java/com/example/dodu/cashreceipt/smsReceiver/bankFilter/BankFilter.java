package com.example.dodu.cashreceipt.smsReceiver.bankFilter;

public interface BankFilter {

    public String nameFiter();
    public String paymentsFilter();
}
