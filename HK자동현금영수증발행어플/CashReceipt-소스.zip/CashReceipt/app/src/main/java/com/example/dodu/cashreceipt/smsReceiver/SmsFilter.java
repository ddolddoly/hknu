package com.example.dodu.cashreceipt.smsReceiver;

import android.util.Log;

import com.example.dodu.cashreceipt.smsReceiver.bankFilter.BankFilter;
import com.example.dodu.cashreceipt.smsReceiver.bankFilter.NonghyupFilter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmsFilter {

    private static final String[] bankName_kr = {"농협", "신한", "기업", "우리"}; // bankName korea name
    private static final String[] bankName_eng = {"nonghyup", "shinhan", "ibk", "woori"}; // bankName english name

    private BankFilter bankFilter;
    private String smsBody;

    public SmsFilter(String smsBody) {

        this.smsBody = smsBody;
        setBankFilter();
    }

    public String isBankSms() {

        String bankName = null;
//        String[] bankName = bankName_kr;
        String[] bankList = bankName_eng;

        Pattern p;
        Matcher m;

        for(int i=0; i<bankList.length; i++) {
            p = Pattern.compile(bankList[i]);
            m = p.matcher(smsBody);

            if(m.find()){
                bankName = bankList[i];
                break;
            }
        }

        return bankName;
    }

    public void setBankFilter() {

        String bankName = isBankSms();
        Log.i("test : ", "iii : " + "iiii1");
        if(bankName != null) {
            switch (bankName) {
//                case "농협" : bankFilter = nsmsBodyew NonghyupFilter(smsBody); break;
                case "nonghyup" : bankFilter = new NonghyupFilter(smsBody); break;
            }
        }
    }

    public String getName() {

        return bankFilter.nameFiter();
    }

    public String getPayments() {

        return bankFilter.paymentsFilter();
    }
}