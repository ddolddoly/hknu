package com.example.dodu.cashreceipt.smsReceiver.bankFilter;

import android.util.Log;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NonghyupFilter implements BankFilter {

    private String smsBody;

    public NonghyupFilter(String smsBody) {
        this.smsBody = smsBody;
    }
    @Override
    public String nameFiter() {
        // name
        StringBuffer line = new StringBuffer();
        String name = null;

//        Pattern p = Pattern.compile("[0-9]+[123456789\\*-]+[0-9]+.[가-힣]{2,}");
        Pattern p = Pattern.compile("[0-9]+[123456789\\*-]+[0-9]+.[a-zA-Z]{4,}");
        Matcher m = p.matcher(smsBody);
        Log.i("test : ", "iii : " + "iiii");

        while(m.find()) {
            line.append(m.group());
            System.out.println(line);
        }

//        p = Pattern.compile("[가-힣]+");
        p = Pattern.compile("[a-zA-Z]+");
        m = p.matcher(line);

        while(m.find()) {
            name = m.group();
            Log.i("test : ", "name : " + name);
        }

        return name;
    }

    @Override
    public String paymentsFilter() {

        StringBuffer line = new StringBuffer();
        String payments = null;

//        p = Pattern.compile("입금.([0123456789,]{5,})");
        Pattern p = Pattern.compile("input.[0123456789,]{5,}");
        Matcher m = p.matcher(smsBody);

        while(m.find()) {
            line.append(m.group());
            Log.i("test : ", "line : " + line);
        }

        //        p = Pattern.compile("입금.([0123456789,]{5,})");
        p = Pattern.compile("([0123456789\\,]{5,})");
        m = p.matcher(line);

        while(m.find()) {
            payments = m.group();
            Log.i("test : ", "payments : " + payments);
        }

        return payments;
    }
}